% Angewandte Numerik 1, SoSe 2020
% Uebungsblatt 10, Aufgabe 44d-e: Konvergenzbereiche
%
% Veranschaulicht fuer die Funktion f(x) = arctan(x) beim Sekanten
% Verfahren die Abhaengigkeiten der Anzahl der Iterationen vom Startwert.
%
% Letzte Aenderung: 28.06.2020

% Cleanup
clearvars;
close all;
clc;

% Initialisierung ---------------------------------------------------------
fprintf( '\nAngewandte Numerik 1, Sommersemester 2020\n' );
fprintf( 'Uebungsblatt 10, Aufgabe 44d-e: Konvergenzbereiche\n' );

% Genauigkeit des y-Werts der Nullstelle (y-Toleranz)
toly   = 1e-10;

% Maximale Anzahl Iterationen der Verfahren
maxIt  = 5000;

% Anzahl der Startwerte
numx0  = 200;

% Vektor fuer Anzahl der Iterationen initialisieren
n1Iter = zeros( 1, numx0 );
n2Iter = zeros( 1, numx0 );

% Vektor fuer Konvergenz initialisieren
noconv1  = false( 1, numx0 );
noconv2  = false( 1, numx0 );

% Definition der Testfunktion
f      = @(x) atan( x );

% Startwerte
x0     = linspace( -10, 10, numx0 );
x1     = -5 * ones( 1, numx0 );
x1(x0 < 0) = 5;

% Sekanten-Verfahren mit unterschiedlichen Startwerten
for k = 1:numx0
  % Berechnung der Iterationswerte mit dem Newton-Verfahren
      
  xk        = sekanten( f, x0(k), x1(k), toly, maxIt );
  % Bestimmung der Anzahl der Iterationswerte
  n1Iter(k) = length( xk );
  % Konvergenz erreicht?
  if( abs( f( xk(end) ) ) > toly || isnan( f( xk(end) ) ) )
    % Keine Konvergenz
    noconv1(k) = true;
  end
end

hf1 = figure( 'Name', 'Angewandte Numerik 1, Blatt 10, Aufgabe 44d-e', ...
  'NumberTitle', 'off', 'Units', 'normalized', 'MenuBar', 'None',      ...
  'Position', [0.1, 0.08, 0.8, 0.87] );
yminmax1 = [ -2, 17 ];
for j = 1:numx0
  if noconv1(j)
    plot( [ x0(j), x0(j) ], yminmax1, 'k-', 'Display', 'Keine Konvergenz' );
    hold on;
    legend( 'autoupdate', 'off' );
  end
end
legend( 'autoupdate', 'on', 'Location', 'NorthEast', 'FontSize', 16 );
plot( x0, n1Iter, '*r-', 'Display', 'Anzahl Iterationen', ...
  'LineWidth', 1.5 );
plot( x0, f(x0), 'b-', 'Display', 'Funktion f(x) = atan(x)', ...
  'LineWidth', 1.5 );
hold off;
ha = gca;
ha.FontSize = 12;
ylim( yminmax1 );
xlabel( 'Startwerte', 'FontSize', 16 );
ylabel( 'Anzahl Iterationen', 'FontSize', 16 );
title( ['Anzahl Iterationen des Sekanten-Verfahren fuer ', ...
  'f(x) = atan(x), x0=[-10,10], x1=+-5'], 'FontSize', 20 );

% Sekanten-Verfahren mit unterschiedlichen Startwerten
for k = 1:numx0
  % Berechnung der Iterationswerte mit dem Newton-Verfahren
      
  xk        = sekanten( f, x1(k), x0(k), toly, maxIt );
  % Bestimmung der Anzahl der Iterationswerte
  n2Iter(k) = length( xk );
  % Konvergenz erreicht?
  if( abs( f( xk(end) ) ) > toly || isnan( f( xk(end) ) ) )
    % Keine Konvergenz
    noconv2(k) = true;
  end
end

hf2 = figure( 'Name', 'Angewandte Numerik 1, Blatt 10, Aufgabe 44d-e', ...
  'NumberTitle', 'off', 'Units', 'normalized', 'MenuBar', 'None',      ...
  'Position', [0.1, 0.08, 0.8, 0.87] );
yminmax2 = [ -2, 21 ];
for j = 1:numx0
  if noconv2(j)
    plot( [ x0(j), x0(j) ], yminmax2, 'k-', 'Display', 'Keine Konvergenz' );
    hold on;
    legend( 'autoupdate', 'off' );
  end
end
legend( 'autoupdate', 'on', 'Location', 'North', 'FontSize', 16 );
plot( x0, n2Iter, '*r-', 'Display', 'Anzahl Iterationen', ...
  'LineWidth', 1.5 );
plot( x0, f(x0), 'b-', 'Display', 'Funktion f(x) = atan(x)', ...
  'LineWidth', 1.5 );
hold off;
ha = gca;
ha.FontSize = 12;
ylim( yminmax2 );
xlabel( 'Startwerte', 'FontSize', 16 );
ylabel( 'Anzahl Iterationen', 'FontSize', 16 );
title( ['Anzahl Iterationen des Sekanten-Verfahren fuer ', ...
  'f(x) = atan(x), x0=+-5, x1=[-10,10]'], 'FontSize', 20 );