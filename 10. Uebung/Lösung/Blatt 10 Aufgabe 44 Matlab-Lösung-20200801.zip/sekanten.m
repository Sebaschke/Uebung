function xk = sekanten( f, a, b, toly, maxIt )
% Angewandte Numerik 1, SoSe 2020
% Uebungsblatt 10, Aufgabe 43: Sekanten-Verfahren
%
% Die Funktion xk = sekanten( f, a, b, toly, maxIt ) berechnet fuer 
% eine stetige Funktion f(x) mit f(a)~=f(b) mit dem Sekantenverfahren
% eine Nullstelle von f(x) beginnend mit den Startwerten a und b mit
% der Genauigkeit toly
% 
%   Input:  f       Stetige Funktion f(x) deren Nullstelle bestimmt
%                   werden soll, mit f(x0)~=f(x1)(function handle)
%           a       1. Startwert
%           b       2. Startwert
%           toly    Toleranz des Funktionswerts an der
%                   naeherungsweise berechneten Nullstelle
%           maxIt   Maximale Anzahl der Iterationen des Verfahrens
%   Output: x       Vektor mit den neu bestimmten Intervallgrenzen,
%                   enthaelt auch die Startwerte: xk(1) = a, xk(2) = b
%
% Letzte Aenderung: 28.06.2020

  % Initialisierung -------------------------------------------------------
  % Toleranz des Funktionswerts an der berechneten Nullstelle
  toly   = abs(toly);
  
  % Maximale Anzahl der Iterationen des Verfahrens
  maxIt  = abs(maxIt);
  
  % Initialisieren des Vektor der Iterierationswerte incl. den Startwerten
  xk     = zeros(1,maxIt+2);
  xk(1)  = a;
  xk(2)  = b;
  fa     = f(a);
  fb     = f(b);

  % Name der uebergebenen Funktion
  fnam   = inputname(1);

  % Bestimmung der Nullstelle der Funktion f(x) ---------------------------
  for k = 3:maxIt+2
    % Iterationsschritt: Neue Intervallgrenze bestimmen und abspeichern
    b     = b - fb * (b - a) / (fb - fa);
    xk(k) = b;
    
    % Wenn f(a) = f(b): Division durch 0: Fehler: b -> +/-inf
    if isinf( b )
      fprintf( 2, ['\nSekanten-Methode: Gleicher Funktionswert ', ...
        '%s(x) an den Randpunkten, k = %d !!\n'], fnam, k );
      break;
    end

    % Zweite Intervallgrenze und ihren Funktionswert anpassen
    a     = xk(k-1);
    fa    = fb;
    
    % Neuen Funktionswert berechnen und Konvergenztest
    fb    = f(b);
    if( abs(fb) < toly )
      break;
    end
  end
  
  % Warnung wenn maximale Anzahl Iterationsschritten erreicht ist
  if ( k > maxIt+1 )
    fprintf( 2, ['\nWarnung: Sekanten-Verfahren: Maximale Anzahl ', ...
      'Iterationen erreicht !\n'] );
  end
  
  % Ausgabevektor verkuerzen, wurde nicht komplett benoetigt
  xk(k+1:end) = [];
end