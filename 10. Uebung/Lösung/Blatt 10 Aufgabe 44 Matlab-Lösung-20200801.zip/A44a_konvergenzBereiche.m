% Angewandte Numerik 1, SoSe 2020
% Uebungsblatt 10, Aufgabe 44a-c: Konvergenzbereiche
%
% Veranschaulicht fuer die Funktion f(x) = arctan(x) beim Newton
% Verfahren die Abhaengigkeiten der Anzahl der Iterationen vom Startwert.
%
% Letzte Aenderung: 28.06.2020

% Cleanup
clearvars;
close all;
clc;

% Initialisierung ---------------------------------------------------------
fprintf( '\nAngewandte Numerik 1, Sommersemester 2020\n' );
fprintf( 'Uebungsblatt 10, Aufgabe 44a-c: Konvergenzbereiche\n' );

% Genauigkeit des y-Werts der Nullstelle (y-Toleranz)
toly   = 1e-10;

% Maximale Anzahl Iterationen der Verfahren
maxIt  = 5000;

% Anzahl der Startwerte
numx0  = 200;

% Vektor fuer Anzahl der Iterationen initialisieren
nIter  = zeros( 1, numx0 );

% Vektor fuer Konvergenz initialisieren
noconv = false( 1, numx0 );

% Definition der Testfunktion
f      = @(x) atan( x );

% Ableitung von f(x) als Function Handle definieren
syms x;
df     = diff(f,x);
df     = matlabFunction(df);
clear x;

% Startwerte
x0     = linspace( -10, 10, numx0 );

% Newton-Verfahren mit unterschiedlichen Startwerten
for k = 1:numx0
  % Berechnung der Iterationswerte mit dem Newton-Verfahren
  xk       = newton1D( f, df, x0(k), toly, maxIt );
  % Bestimmung der Anzahl der Iterationswerte
  nIter(k) = length( xk );
  % Konvergenz erreicht?
  if( abs( f( xk(end) ) ) > toly || isnan( f( xk(end) ) ) )
    % Keine Konvergenz
    noconv(k) = true;
  end
end

hf1 = figure( 'Name', 'Angewandte Numerik 1, Blatt 10, Aufgabe 44a-c', ...
  'NumberTitle', 'off', 'Units', 'normalized', 'MenuBar', 'None',      ...
  'Position', [0.1, 0.08, 0.8, 0.87] );
yminmax = [ -2, 15 ];
for j = 1:numx0
  if noconv(j)
    plot( [ x0(j), x0(j) ], yminmax, 'k-', 'Display', 'Keine Konvergenz' );
    hold on;
    legend( 'autoupdate', 'off' );
  end
end
legend( 'autoupdate', 'on', 'Location', 'East', 'FontSize', 16 );
plot( x0, nIter, '*r-', 'Display', 'Anzahl Iterationen', ...
  'LineWidth', 1.5 );
plot( x0, f(x0), 'b-', 'Display', 'Funktion f(x) = atan(x)', ...
  'LineWidth', 1.5 );
hold off;
ha = gca;
ha.FontSize = 12;
ylim( yminmax );
xlabel( 'Startwerte', 'FontSize', 16 );
ylabel( 'Anzahl Iterationen', 'FontSize', 16 );
title( 'Anzahl Iterationen des Newton-Verfahren fuer f(x) = atan(x)', ...
  'FontSize', 20 );