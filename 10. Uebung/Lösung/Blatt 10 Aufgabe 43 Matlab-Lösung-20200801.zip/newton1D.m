function xk = newton1D( f, df, x0, toly, maxIt )
% Angewandte Numerik 1, SoSe 2020
% Uebungsblatt 10, Aufgabe 42: Newton-Verfahren
%
% Naeherungsweise Berechnung der Nullstelle eines nichtlinearen
% Gleichungssystem f(x) mit Hilfe des Newton-Verfahrens fuer eine
% Toleranz toly des Funktionswertes an der Nullstelle beginnend
% mit dem Startwert x0.
%
% Input:    f       Nichtlineares Gleichungssystem f(x) als
%                   function handle
%           df      Ableitung der Funktion f(x) als function handle
%           x0      Startwert des Newtonverfahrens
%           toly    Toleranz des Funktionswerts an der
%                   naeherungsweise berechneten Nullstelle
%           maxIt   Maximale Anzahl an Iterationen 
% Output:   xk      Vektor mit den berechneten Iterationswerten
%                   aller Iterationen, inklusive des Startwerts
%
% Letzte Aenderung: 28.06.2020

  % Initialisierung -------------------------------------------------------
  toly  = abs(toly);
  maxIt = abs(maxIt);
  
  % Name der uebergebenen Ableitung
  dfnam = inputname(2);
  
  % Initialisieren des Vektor der Iterierationswerte incl. dem Startwert
  xk    = zeros( 1, maxIt + 1 );
  xk(1) = x0;
  
  % Funktionswert des Startwerts
  Fx    = f(x0);

  % Newton-Verfahren mit Konvergenztest -----------------------------------
  for k = 2:maxIt + 1
    % Newtonschritt durchfuehren: Neuer Startpunkt
    xk(k) = xk(k-1) - Fx / df( xk(k-1) );
    
    % Ueberpruefen, ob Ableitung null war
    if isinf( xk(k) )
      fprintf( 2, ['\nFehler: Newton-Verfahren: Ableitung %s(x) = 0 ', ...
        'bei Startwert x0 =%5.1f, k = %d !!\n'], dfnam, x0, k );
      break;
    end
    
    % Neuen Funktionswert berechnen
    Fx  = f( xk(k) );
    
    % Konvergenztest
    if( abs(Fx) < toly )
      break;
    end
  end
 
  % Warnung wenn maximale Anzahl Iterationsschritten erreicht ist
  if ( k > maxIt )
    fprintf( 2, ['\nWarnung: Newton-Verfahren: Maximale Anzahl ', ...
      'Iterationen erreicht !\n'] );
  end
  
  % Warnung wenn keine Konvergenz erreicht wurde
  if( abs( f( xk(k) ) ) > toly || isnan( f( xk(k) ) ) )
    fprintf( 2, ['\nWarnung: Newton-Verfahren: Keine Konvergenz ', ...
      'erreicht fuer Funktion %s(x) mit Startwert%6.2f\n'],         ...
      inputname(1), x0 );
  end
  
  % Ausgabevektor verkuerzen, wurde nicht komplett benoetigt
  xk(:,k+1:end) = [];
end