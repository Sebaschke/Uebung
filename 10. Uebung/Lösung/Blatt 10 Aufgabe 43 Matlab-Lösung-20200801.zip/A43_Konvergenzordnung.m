% Angewandte Numerik 1, SoSe 2020
% Uebungsblatt 10, Aufgabe 43: Konvergenzordnungen
%
% Es wird die Konvergenzordnung des Bisektionsverfahren, des Newton-
% und des Sekantenverfahren fuer 2 Funktionen untersucht, wobei die
% zweite Funktion eine doppelte Nullstelle hat.
%
% Visualisiert wie sich der Fehler |xk ? x?| (y-Achse) der
% 3 Verfahrens in jedem Iterationsschritt (x-Achse) entwickelt.
%
% Letzte Aenderung: 28.06.2020

% Cleanup
clearvars;
close all;
clc;

% Initialisierung ---------------------------------------------------------
fprintf( '\nAngewandte Numerik 1, Sommersemester 2020\n' );
fprintf( 'Uebungsblatt 10, Aufgabe 43: Konvergenzordnungen\n' );

% Genauigkeit bei der Bestimmung der Nullstelle (x-Toleranz)
tolx  = 1e-14;

% Genauigkeit des y-Werts der Nullstelle (y-Toleranz)
toly  = 1e-14;

% Maximale Anzahl Iterationen der Verfahren
maxIt = 1000;

%=== 1. Testfunktion ======================================================
fprintf( '\n==========================================================\n');
fprintf( '\nTestfunktion f1(x) = x^2 - cos( x )\n' );

% Definition der 1. Testfunktion
f1   = @(x) x.^2 - cos( x );

% Bestimmung der Nullstelle mit dem Matlab Befehl fzero, Startwert 1
xs1  = fzero( f1, 1 );

hf1  = figure( 'Name', 'Angewandte Numerik 1, Blatt 10, Aufgabe 43', ...
  'NumberTitle', 'off', 'Units', 'normalized', 'MenuBar', 'None',    ...
  'Position', [0.1, 0.08, 0.8, 0.87] );

% Bisektionsverfahren -----------------------------------------------------
% Startintervall des Bisektionsverfahrens
Ba1   = 0.0;
Bb1   = 3.0;

% Bestimmung der Nullstelle mit dem Bisektionsverfahren
B1xk   = bisektion1( f1, Ba1, Bb1, tolx, maxIt );

% Anzahl der Iterationen
B1iter = length( B1xk );

% Bestimmung des Fehlers
B1xErr = abs( B1xk - xs1 );

% Visualisierung des Fehlers |xk ? x?| des Bisektionsverfahrens
semilogy( 1:B1iter, B1xErr, '*r-', 'LineWidth', 1.5, 'Display', ...
  'Bisektionsverfahren' );
hold on;

% Newton-Verfahren --------------------------------------------------------
% Startwerte des Newton-Verfahrens
x0_1 = 3.0;
x0_2 = 0.0;
x0_3 = 40.0;

% Ableitung von f1(x) als Function Handle definieren
syms x;
df1  = diff(f1,x);
df1  = matlabFunction(df1);
clear x;

% Nullstelle der Funktion f(x) mit Newton-Verfahren bestimmen, 1.Startwert
N1xk = newton1D( f1, df1, x0_1, toly, maxIt );

% Anzahl der Iterationen
N1iter = length( N1xk );

% Bestimmung des Fehlers
N1xErr = abs( N1xk - xs1 );

% Plotten des Fehlers |xk ? x?| des Newton-Verfahrens, 1. Startwert
semilogy( 1:N1iter, N1xErr, 'db-', 'LineWidth', 1.5, 'Display', ...
  [ 'Newton-Verfahren, x0=', num2str(x0_1) ] );

% Nullstelle der Funktion f(x) mit Newton-Verfahren bestimmen, 2.Startwert
N2xk = newton1D( f1, df1, x0_2, toly, maxIt );

% Anzahl der Iterationen
N2iter = length( N2xk );

% Bestimmung des Fehlers, zum Plotten Inf-Werte auf 1e10 setzen
N2xErr = abs( N2xk - xs1 );
N2xErr(isinf(N2xErr))=1e10;

% Plotten des Fehlers |xk ? x?| des Newton-Verfahrens, 2. Startwert
semilogy( 1:N2iter, N2xErr, 'sg-', 'LineWidth', 1.5, 'Display', ...
  [ 'Newton-Verfahren, x0=', num2str(x0_2) ] );

% Nullstelle der Funktion f(x) mit Newton-Verfahren bestimmen, 3.Startwert
N3xk = newton1D( f1, df1, x0_3, toly, maxIt );

% Anzahl der Iterationen
N3iter = length( N3xk );

% Bestimmung des Fehlers
N3xErr = abs( N3xk - xs1 );

% Plotten des Fehlers |xk ? x?| des Newton-Verfahrens, 3. Startwert
semilogy( 1:N3iter, N3xErr, 'oc-', 'LineWidth', 1.5, 'Display', ...
  [ 'Newton-Verfahren, x0=', num2str(x0_3) ] );

% Sekanten-Verfahren ------------------------------------------------------
% Startwerte des Sekantenverfahrens
Sa1     = 0.0;
Sb1     = 3.0;

% Nullstelle der Funktion f(x) mit Sekanten-Verfahren bestimmen
S1xk = sekanten( f1, Sa1, Sb1, toly, maxIt );

% Test ob Sekanten-Verfahren konvergiert
if isempty(S1xk)
  fprintf( 2, '\nKeine Konvergenz des Sekanten-Verfahrens !\n' );
else
  % Anzahl der Iterationen
  S1iter = length( S1xk );

  % Bestimmung des Fehlers
  S1xErr = abs( S1xk - xs1 );
  
  % Plotten des Fehlers |xk ? x?| des Sekanten-Verfahrens
  semilogy( 1:S1iter, S1xErr, 'xm-', 'LineWidth', 1.5, 'Display', ...
    'Sekanten-Verfahren' );
end

axis( [ 0, B1iter+1, 2e-13, 100 ] );
ha = gca;
ha.FontSize = 12;
xlabel( 'Iterationen', 'FontSize', 16 );
ylabel( 'Fehler |x_k - x^*|', 'FontSize', 16 );
legend( 'show', 'Location', 'NorthEast', 'FontSize', 16 );
title ...
  ( 'Konvergenz bei der Bestimmung der Nullstelle von f(x)=x^2-cos(x)', ...
  'FontSize', 20 );

%=== 2. Testfunktion ======================================================
fprintf( '\n==========================================================\n');
fprintf( '\nTestfunktion f2(x) = (x-1)^2\n' );

% Definition der 2. Testfunktion
f2   = @(x) (x-1).^2;

% Bestimmung der Nullstelle mit dem Matlab Befehl fzero, Startwert 1
xs2  = fzero( f2, 1 );

hf2  = figure( 'Name', 'Angewandte Numerik 1, Blatt 10, Aufgabe 43', ...
  'NumberTitle', 'off', 'Units', 'normalized', 'MenuBar', 'None',    ...
  'Position', [0.1, 0.08, 0.8, 0.87] );

% Bisektionsverfahren -----------------------------------------------------
% Startintervall des Bisektionsverfahrens
Ba2     = 0.1;
Bb2     = 3.0;

% Bestimmung der Nullstelle mit dem Bisektionsverfahren
B2xk   = bisektion1( f2, Ba2, Bb2, tolx, maxIt );

% Anzahl der Iterationen
B2iter = length( B2xk );

% Bestimmung des Fehlers
B2xErr = abs( B2xk - xs2 );

% Visualisierung des Fehlers |xk ? x?| des Bisektionsverfahrens
semilogy( 1:B2iter, B2xErr, '*r-', 'LineWidth', 1.5, 'Display', ...
  'Bisektionsverfahren' );
hold on;

% Newton-Verfahren --------------------------------------------------------
% Startwerte des Newton-Verfahrens
x0_4  = 3.0;

% Ableitung von f2(x) als Function Handle definieren
syms x;
df2  = diff(f2,x);
df2  = matlabFunction(df2);
clear x;

% Nullstelle der Funktion f(x) mit Newton-Verfahren bestimmen, 4.Startwert
N4xk = newton1D( f2, df2, x0_4, toly, maxIt );

% Anzahl der Iterationen
N4iter = length( N4xk );

% Bestimmung des Fehlers
N4xErr = abs( N4xk - xs2 );

% Plotten des Fehlers |xk ? x?| des Newton-Verfahrens, 4. Startwert
semilogy( 1:N4iter, N4xErr, 'db-', 'LineWidth', 1.5, 'Display', ...
  'Newton-Verfahren' );

% Sekanten-Verfahren ------------------------------------------------------
% Startwerte des Sekantenverfahrens
Sa2     = 0.1;
Sb2     = 3.0;

% Nullstelle der Funktion f(x) mit Sekanten-Verfahren bestimmen
S2xk = sekanten( f2, Sa2, Sb2, toly, maxIt );

% Test ob Sekanten-Verfahren konvergiert
if isempty(S2xk)
  fprintf( 2, '\nKeine Konvergenz des Sekanten-Verfahrens !\n' );
else
  % Anzahl der Iterationen
  S2iter = length( S2xk );

  % Bestimmung des Fehlers
  S2xErr = abs( S2xk - xs2 );
  
  % Plotten des Fehlers |xk ? x?| des Sekanten-Verfahrens
  semilogy( 1:S2iter, S2xErr, 'xm-', 'LineWidth', 1.5, 'Display', ...
    'Sekanten-Verfahren' );
end

axis( [ 0, B2iter, 2e-8, 30 ] );
ha = gca;
ha.FontSize = 12;
xlabel( 'Iterationen', 'FontSize', 16 );
ylabel( 'Fehler |x_k - x^*|', 'FontSize', 16 );
legend( 'show', 'Location', 'East', 'FontSize', 16 );
title ...
  ( 'Konvergenz bei der Bestimmung der Nullstelle von f(x)=(x-1)^2', ...
  'FontSize', 20 );