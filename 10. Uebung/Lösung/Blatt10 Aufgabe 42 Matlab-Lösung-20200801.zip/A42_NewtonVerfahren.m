% Angewandte Numerik 1, SoSe 2020
% Uebungsblatt 10, Aufgabe 42: Newton-Verfahren
%
% Loest das nichtlineare Gleichungssystem x2 = 5 naeherungsweise
% mit dem Newton-Verfahren, Startwert x0 = 1.
%
% Letzte Aenderung: 28.06.2020

% Cleanup
clearvars;
close all;
clc;

% Initialisierung ---------------------------------------------------------
fprintf( '\nAngewandte Numerik 1, Sommersemester 2020\n' );
fprintf( 'Uebungsblatt 10, Aufgabe 42: Newton-Verfahren\n\n' );

% Startwert des Newton-Verfahrens
x0    = 1;

% Maximale Anzahl der Iterationen des Verfahrens
maxIt = 1000;

% Toleranz des Funktionswert an der naeherungsweise berechneten Nullstelle
toly  = 1e-14; 

% Function Handle von Funktion und Ableitung ------------------------------
% Funktion f(x) als Function Handle definieren
f  = @(x) x.^2 - 5;

% Ableitung von f(x) als Function Handle definieren
syms x;
df  = diff(f,x);
df  = matlabFunction(df);
clear x;

% Nullstellenberechnung ---------------------------------------------------
% Nullstelle der Funktion f(x) mit dem Newton-Verfahren bestimmen
xk = newton1D( f, df, x0, toly, maxIt );

% Bestimmung der Nullstelle mit dem Matlab Befehl fzero, Startwert 1
xs = fzero( f, 1 );

% Bestimmung des Fehlers
xErr = abs( xk - xs );

% Ausgabe des Iterationsverlaufs
for k = 1:length( xk )
  fprintf( 'Iteration %2d: Nullstelle: %16.13f, Fehler: %9.4g\n', ...
    k-1, xk(k), xErr(k) );
end