% Angewandte Numerik 1, SoSe 2020
% Uebungsblatt 10, Aufgabe 41: Konvergenz des Bisektionsverfahrens
%
% Berechnet die Nullstelle der Funktion f(x) = x^2?cos(x) auf
% 10 Nachkommastellen genau mit dem Startintervall [0,3].
% Visualisiert wie sich der Fehler |xk ? x?| (y-Achse) waehrend
% des Bisektionsverfahrens in jedem Iterationsschritt (x-Achse)
% entwickelt.
%
% Letzte Aenderung: 28.06.2020

% Cleanup
clearvars;
close all;
clc;

% Initialisierung ---------------------------------------------------------
fprintf( '\nAngewandte Numerik 1, Sommersemester 2020\n' );
fprintf( 'Uebungsblatt 10, Aufgabe 41: Bisektionsverfahren\n\n' );
% Startintervall
a    = 0;
b    = 3;

% Maximale Anzahl der Iterationen
maxIt  = 5000;

% Genauigkeit bei der Bestimmung der Nullstelle (x-Toleranz)
tolx = 1e-10;

% Definition der Testfunktion
f    = @(x) x.^2 - cos( x );

% Bestimmung der Nullstelle und des Fehlers -------------------------------
% Bestimmung der Nullstelle mit dem Matlab Befehl fzero, Startwert 1
xs   = fzero( f, 1 );

% Bestimmung der Nullstelle mit dem Bisektionsverfahren
xk   = bisektion1( f, a, b, tolx, maxIt );

% Anzahl der Iterationen
iter = length( xk );

% Bestimmung des Fehlers
xErr = abs( xk - xs );

% Visualisierung des Fehlers |x_k - x^*| des Bisektionsverfahrens ---------
hf1 = figure( 'Name', 'Angewandte Numerik 1, Blatt 10, Aufgabe 41', ...
  'NumberTitle', 'off', 'Units', 'normalized', 'MenuBar', 'None',   ...
  'Position', [0.1, 0.08, 0.8, 0.87] );
semilogy( 1:iter, xErr, '*r-' );
axis( [ 0, iter+1, 1e-11, 1 ] );
ha = gca;
ha.FontSize = 12;
xlabel( 'Iterationen', 'FontSize', 16 );
ylabel( 'Fehler |x_k - x^*|', 'FontSize', 16 );
title( ['Bestimmung der Nullstelle von f(x)=x^2-cos(x) mit dem ', ...
  'Bisektionsverfahrens'], 'FontSize', 20 );