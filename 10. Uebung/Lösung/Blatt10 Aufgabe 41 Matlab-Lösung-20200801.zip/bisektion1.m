function xk = bisektion1( f, a, b, tolx, maxIt )
% Angewandte Numerik 1, SoSe 2020
% Uebungsblatt 10, Aufgabe 41: Konvergenz des Bisektionsverfahrens
%
% Die Function xk = bisektion1( f, a, b, tolx ) bestimmt fuer eine
% stetige Funktion f im Intervall [a,b] mit dem Bisektionsverfahren
% naeherungsweise die Loesung einer Gleichung f(x) = 0.
% Die Nullstelle von f(x) wird mit der Genauigkeit tolx bestimmt.
% Es wird ein Vektor mit den Iterationswerten xk aller durchgefuehrten
% Iterationen zurueckgeben.
% Es wird eine Warnung ausgegeben wenn die Bedingung f(a)*f(b)<0
% nicht erfuellt ist.
%
%   Input:  f       Stetige Funktion f(x) mit f(a)*f(b) < 0 
%                   (function handle)
%           a       1. Intervallgrenze
%           b       2. Intervallgrenze
%           tolx    Genauigkeit bei der Bestimmung der Nullstelle
%           maxIt   Maximale Anzahl der Iterationen
%   Output: xk      Vektor mit allen Iterationswerten der einzelnen
%                   Schritte

  % Initialisierung -------------------------------------------------------
  % Genauigkeit bei der Bestimmung der Nullstelle (x-Toleranz)
  tolx   = abs(tolx);
  
  % Genauigkeit des y-Werts der Nullstelle (y-Toleranz)
  toly   = eps;
  
  % Funktionswert an der 1. Intervallgrenze
  fa     = f(a);
  
  % Name der uebergebenen Funktion
  fnam   = inputname(1);
  
  % Initialisierung des Ausgabevektors
  xk     = zeros(1,maxIt);

  % Warnungen -------------------------------------------------------------
  % Bedingung f(x0)*f(x1) < 0 erfuellt?
  if( f( ( a + b) / 2 ) ~= 0 && fa*f(b) >= 0 )
    fprintf( 2, ['\nWarnung: Bisektion: Funktion %s erfuellt ', ...
      'Bedingung %s(a)*%s(b)<0 nicht\n\n'], fnam, fnam, fnam);
  end
  
  % Bestimmung der Nullstelle der Funktion f(x) ---------------------------
  for k = 1:maxIt
    m     = ( a + b) / 2;
    xk(k) = m;
    fm    = f(m);
    if ( fa * fm < 0 )
      b   = m;
    else
      a   = m;
      fa  = fm;
    end
    if ( abs( fm ) < toly || abs( b - a ) < tolx )
      break;
    end
  end
  % Ausgabevektor verkuerzen
  xk(k+1:end) = [];
end