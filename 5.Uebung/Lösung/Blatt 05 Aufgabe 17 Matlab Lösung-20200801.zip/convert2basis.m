function a = convert2basis( n, b )
% Angewandte Numerik 1, SoSe 2020
% Uebungsblatt 05, Aufgabe 17: Darstellung natuerlicher Zahlen
%
% Die Funktion a = convert2basis( n, b ) berechnet fuer eine
% natuerliche Zahl n und eine Basis b den Koeffizienten-Vektor a mit
% a = (a_m, a_{m-1}, ..., a_1, a_0) der Darstellung von n zur Basis b.
%
% Input:    n   Natuerliche Zahl, fuer die der Koeffizienten-Vektor
%               berechnet werden soll
%           b   Basis, zu der die Zahldarstellung gesucht wird,
%               b in N, b>=2
% Output:   a   Koeffizienten-Vektor der Zahl n zur Basis b
%               a = (a_m, a_{m-1}, ..., a_1, a_0)
%
% Letzte Aenderung: 28.05.2020

  % Fehlerbehandlung ------------------------------------------------------
  a = NaN;
  if( b < 2 || mod(b,1) ~= 0 )
    % b ist kleiner 2 oder nicht ganzzahlig
    fprintf('\nb ist keine ganzzahlige Basis >= 2 !\n\n');
    return;
  end
  if( n < 0 || mod(n,1) ~= 0 )
    % n ist keine natuerliche Zahl
    fprintf('\nn ist keine natuerliche Zahl !\n\n');
    return;
  end
  
  % Berechnung des Koeffizienten-Vektor -----------------------------------
  if ( b > n )
    % Zahl kleiner als Basis: Koeffizienten-Vektor = Zahl
    a = n;
  else
    % Bestimmung der Dimension des Koeffizienten-Vektor -------------------
    m     = 2;
    btemp = b;
    while ( n / btemp >= b )
      m = m + 1;
      btemp = b * btemp;
    end
    
    % Zweite Moeglichkeit:
    % hier gilt: b^m - 1  >= n,
    % <=>        b^m      >= n+1,
    % <=>        m*log(b) >= log(n+1)
    % <=>        m        >= log(n+1)/log(b)
    % m = ceil(log(n+1)/log(b));

    % Bestimmung des Koeffizienten-Vektor ---------------------------------
    % Beachte: a(m) = a_0     ist Koeffizient fuer b^0
    %          a(2) = a_{m-2} ist Koeffizient fuer b^(m-2)
    %          a(1) = a_{m-1} ist Koeffizient fuer b^(m-1)
    
    % Initialisierung des Koeffizienten-Vektor
    a = zeros(1,m);
    
    ntemp = n;
    for j = m:-1:1
      a(j)= mod( ntemp, b );
      ntemp = floor( ntemp / b );  % Abrundung auf naechst kleinere Integer
    end
  end
end