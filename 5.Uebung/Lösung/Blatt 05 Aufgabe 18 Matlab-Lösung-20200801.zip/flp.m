function [d, v, t] = flp( b, m, n, x )
% Angewandte Numerik 1, SoSe 2020
% Uebungsblatt 05, Aufgabe 18: Wert einer Gleitpunkt-Darstellung
%
% Die Funktion [d, v, t] = flp( b, m, n, x ) berechnet zu einer Basis
% b in N, b>=2, einer Mantissenlaenge m, einer Exponentenlaenge n und einer
% zu konvertierenden Zahl x deren normalisierte Gleitpunkt-Darstellung
% und liefert d, v sowie t zurueck.
%
% Input:    b     Basis, zu der die Zahldarstellung gesucht wird,
%                 b in N, b>=2
%           m     Mantissenlaenge
%           n     Exponentenlaenge
%           x     Die zu konvertierende Dezimalzahl
% Output:   d     Zeilenvektor fuer die Koeffizienten der Mantisse
%           v     Zeilenvektor fuer die Koeffizienten des Exponenten
%           t     Vorzeichen des Exponenten, t in {-1,1}
%
% Letzte Aenderung: 28.05.2020

  % Fehlerbehandlung ------------------------------------------------------
  d = NaN;
  v = NaN;
  t = NaN;
  
  if( b < 2 || mod(b,1) ~= 0 )
    % b ist kleiner 2 oder nicht ganzzahlig
    fprintf('\nb ist keine ganzzahlige Basis >= 2 !\n\n');
    return;
  end
  
  if( x < 0 )
    % Zahl ist nicht positiv
    fprintf(2, '\nDie Zahl ist nicht positiv !\n\n');
    return
  end
  
  % Initialisierung -------------------------------------------------------
  y = b * x;
  % Exponent zur Basis
  e = 0;
  % Zeilenvektor der Mantisse der konvertierten Zahl
  d = zeros(1,m);
  % Zeilenvektor des Exponenten der konvertierten Zahl
  v = zeros(1,n);
  % Zahlenwert innerhalb der Gauss Klammer
  g = y;
  % Laufvariable zur Mantissenberechnung
  a = x;
  
  % 1. Fall: 0 < b*x < 1 --------------------------------------------------
  if ( y > 0 && y < 1 )
    % Negatives Vorzeichen des Exponenten
    t = -1;
    
    % Bestimme den Exponenten
    while ( fix(g) < 1 )
      g = b * g;
      e = e + 1;
    end
        
    % Bestimmung der Koeffizienten der Mantisse
    for j=1:1:m
      d(j) = fix( g );
      g = ( g - d(j) ) * b;
    end
    
  % 2. Fall: b*x >= 1 -----------------------------------------------------
  elseif y >= 1
    % Positives Vorzeichen des Exponenten
    t = 1;
        
    % Bestimme den Exponenten
    e = fix( log(x) / log(b) ) + 1;
    
    % Bestimmung der Koeffizienten der Mantisse
    p = b ^ e;
    for j=1:1:m
      p = p / b;
      d(j) = fix( a / p );
      a = a - d(j) * p;
    end
    
  % 3. Fall: Die Zahl ist null --------------------------------------------
  else
    d = 0;
    v = 0;
    t = 1;
  end
  
  % Bestimmung der Koeffizienten des Exponenten ---------------------------
  for k = n:-1:1
    v(k) = mod( e, b );
    e = fix( e / b );
  end
  
  % Overflow?
  if ( e > 0 )
    fprintf(2, '\nOverflow: Exponent nicht darstellbar !\n\n');
    d = NaN;
    v = NaN;
    t = NaN;
  end
end