function x = value( b, d, v, t )
% Angewandte Numerik 1, SoSe 2020
% Uebungsblatt 05, Aufgabe 18: Wert einer Gleitpunkt-Darstellung
%
% Die Funktion x = value( b, d, v, t ) berechnet fuer eine 
% gegebene Gleitpunktdarstellung, also fuer eine Basis 
% b in N, b>=2, einen Zeilenvektor d der Koeffizienten der 
% Mantisse (d = (d_1,d_2,...,d_m)), einen Zeilenvektor v der 
% Koeffizienten des Exponenten (v = (v_n-1,...,v_1,v_0)) sowie
% ein Vorzeichen t (t in{-1,1}) des Exponenten, den Wert x der
% Gleitpunkt-Darstellung
%
% Input:    b   Basis b in N, b>=2
%           d   Zeilenvektor fuer die Koeffizienten der Mantisse
%           v   Zeilenvektor fuer die Koeffizienten des Exponenten
%           t   Vorzeichen des Exponenten, t in {-1,1}
% Output:   x   Wert der Gleitpunkt-Darstellung
%
% Letzte Aenderung: 28.05.2020

  % Initialisierung -------------------------------------------------------
  m = size(d,2);
  n = size(v,2);
  x = NaN;
  
  % Sicherstellen, dass d und v Zeilenvektoren sind
  d = d(:)';
  v = v(:)';
  
  % Mantisse
  mantisse = 0;
  % Exponent
  exponent = 0;
  
  % Fehlerbehandlung ------------------------------------------------------
  if( b < 2 || mod(b,1) ~= 0 )
    % b ist kleiner 2 oder nicht ganzzahlig
    fprintf('\nb ist keine ganzzahlige Basis >= 2 !\n\n');
    return;
  end
  if( abs(t) ~= 1 )
    % t ist kein Vorzeichen
    fprintf('\nt ist kein Vorzeichen !\n\n');
    return
  end
  
  % Berechnung des Exponenten ---------------------------------------------
  fakt = 1;               % Basis^(j)
  for j = n:-1:1
    % v(1):hoechstwertigste Koeffizient
    exponent = exponent + v(j) * fakt;
    fakt     = fakt * b;
  end
  
  % Berechnung der Mantisse -----------------------------------------------
  % Zur Vermeidung von Ausloeschung zuerst die kleinen, dann 
  % die grossen Werte summieren
  for k = m:-1:1
    mantisse = mantisse + d(k) * b^(-k);
  end
  
  % Berechnung des Rueckgabewertes ----------------------------------------
  x = mantisse * b ^ ( t * exponent );
end