function xks = fixPktIt( phi, anzIt, x0 )
% Angewandte Numerik 1, SoSe 2020
% Uebungsblatt 9, Aufgabe 36: Fixpunktiteration
%
% Die Funktion xks = fixPktIt( phi, anzIt, x0 ) fuehrt fuer
% eine Funktion phi beginnend bei einem Startwert x0 eine
% Fixpunktiteration durch und gibt das Ergebnis der 
% Fixpunktiteration nach anzIt Iterationen zurueck
%
% Input:  phi     Funktion, fuer die eine Fixpunktiteration
%                 durchgefuehrt werden soll
%         anzIt   Anzahl der Iterationen der Fixpunktiteration
%         x0      Startwert der Fixpunktiteration
% Output: xks     Spaltenvektor, enthaelt den Startwert und die
%                 ersten anzIt Iterierten
%
% Letzte Aenderung: 21.06.2020

  % Initialisierung
  anzIt  = abs(anzIt);
  xks    = zeros( anzIt + 1, 1 );
  xks(1) = x0;
  
  % Fixpunktiteration
  for k = 2:anzIt+1
    xks(k) = phi( xks(k-1) );
  end
end