% Angewandte Numerik 1, SoSe 2020
% Uebungsblatt 9, Aufgabe 36: Fixpunktiteration
%
% Fuer vier Iterationsfunktionen phi(i) werden jeweils die ersten
% 10 Iterierten beginnend beim Startwert x0 = 5/2 berechnet und
% diese in einer Tabelle ausgegeben.
% Die vier Iterationsfunktionen und die ersten drei Iterierten
% werden geplottet.
%
% Letzte Aenderung: 21.06.2020

% Cleanup -----------------------------------------------------------------
clearvars;
close all;
clc;

% Initialisierung ---------------------------------------------------------
fprintf( '\nAngewandte Numerik 1, Sommersemester 2020\n' );
fprintf( 'Uebungsblatt 9, Aufgabe 36: Fixpunktiteration\n\n' );

% Startwert
x0    = 5 / 2;

% Maximale Anzahl Iterationen
anzIt = 10;

% Anzahl der x-Werte bei Plots
xPlot = 200;

% Iterationsfunktionen ----------------------------------------------------
% Definition der Iterationsfunktionen
phi{1} = @(x) 5 + x - x.^2;
phi{2} = @(x) 5 ./ x;
phi{3} = @(x) 1 + x - x.^2 / 5;
phi{4} = @(x) ( x + 5 ./ x ) / 2;
numphi = length(phi);

% Ausgabe der der Iterationsfunktionen
fprintf( 'Iterationsfunktionen:\n' );
for k = 1:numphi
  fprintf( 'phi%d = %s\n', k, extractAfter( func2str( phi{k} ), '@(x)' ) );
end

% Berechnung der Iterierten der 4 Iterationsfunktionen --------------------
% Initialisierung der Matrix
xks = zeros( anzIt+1, numphi );

% Berechnung der ersten 10 Iterierten der 4 Iterationsfunktionen
for k = 1:length(phi)
  xks(:,k) = fixPktIt( phi{k}, anzIt, x0 );
end

% Tabelle der ersten 10 Iterierten der 4 Iterationsfunktionen
fprintf('\nIndex k | phi1(x_k)  | phi2(x_k) | phi3(x_k) | phi4(x_k) |\n');
fprintf('--------|------------|-----------|-----------|-----------|\n');
for k = 1:anzIt+1
  fprintf('   %2d   | %10.3g | %9.7f | %9.7f | %9.7f |\n', ...
    k - 1, xks(k,1:4) );
end

% Definitionen fuer die Plot-Ausgabe --------------------------------------
% Positionen der Subplots
subppos = [0.060, 0.54, 0.430, 0.32; ...
           0.555, 0.54, 0.430, 0.32; ...
           0.060, 0.08, 0.430, 0.32; ...
           0.555, 0.08, 0.430, 0.32];
         
% Farben der Iterationsschritte
linespec = [ "r-", "g-", "m-" ];

% Position der Legenden in den Subplots
legLocat = [ "SouthEast", "NorthEast", "NorthWest", "North" ];

% x-Intervalle der Subplots
xLimits = [ -5, 5; 0.5, 4; 0.5, 4; 0.5, 4 ];

% y-Intervalle der Subplots
yLimits  = [ -30.0, 10.0; -0.5, 10.0; -0.5, 6.0; -0.5, 6.0 ];

% Plotten der Iterationsfunktionen und erster Iterationsschritte ----------
hf1 = figure( 'Name', 'Angewandte Numerik 1, Blatt 9, Aufgabe 36',  ...
  'NumberTitle', 'off', 'Units', 'normalized', 'MenuBar', 'None',   ...
  'Position', [0.1, 0.07, 0.8, 0.88] );

for k = 1:numphi
  subplot( 'Position', subppos(k,:) );
  
  % Plotten der Iterationsfunktionen
  a = xLimits(k,1);
  b = xLimits(k,2);
  xvals = linspace( a, b, xPlot );
  yvals = phi{k}(xvals);
  plot( xvals, yvals, 'b-', 'LineWidth', 2, ...
    'Display', [ 'Funktion phi', num2str(k) ]);
  hold on
  
  % Plotten der Winkelhalbierenden
  plot([ a b ], [ a b ], 'k-', 'LineWidth', 2, ...
    'Display', 'Winkelhalbierende' );
  
  % Plotten der x-Achse
  plot([ a b ], [ 0 0 ], 'c-', 'LineWidth', 2, 'Display', 'x-Achse' );
  
  % Plotten der ersten 3 Iterationsschritte
  for j = 1:3
    xIter = [ xks(j,k), xks(j,k), a, xks(j+1,k), xks(j+1,k) ];
    yIter = [ 0, xks(j+1,k), xks(j+1,k), xks(j+1,k), 0 ];
    plot( xIter, yIter, linespec(j), ...
      'Display', [ num2str(j), '-ter Iteratiosschritt' ] );
  end
  hold off
  
  % Achsen
  xlim( [ a, b ] );
  ylim( yLimits(k,:) );
  xlabel( 'x-Wert', 'FontSize', 14 );
  ylabel( 'y-Wert', 'FontSize', 14 );
  
  % Legende und Titel
  legend( 'show', 'FontSize', 11, 'Location', legLocat(k), ...
    'NumColumns', 2 );
  str = sprintf('Iterationsfunktion phi%d = %s\n', k, ...
    extractAfter( func2str( phi{k} ), '@(x)' ) );
  ht             = title( str, 'FontSize', 20 );
  ht.Units       = 'normalized';
  ht.Position(2) = ht.Position(2) * 0.85;
end
sgtitle ...
  ( 'Verlauf der Fixpunktiteration fuer mehrere Iterationsfunktionen', ...
  'FontSize', 22 );