% Angewandte Numerik 1, SoSe 2020
% Uebungsblatt 9, Aufgabe 39: Bisektionsverfahren
%
% Bestimmt die Loesung von Gleichungen f(x) = 0 im Intervall [a; b]
% mit dem Bisektionsverfahren auf zwei Nachkommastellen genau.
%
% Letzte Aenderung: 21.06.2020

% Cleanup -----------------------------------------------------------------
clearvars;
close all;
clc;

% Initialisierung ---------------------------------------------------------
fprintf( '\nAngewandte Numerik 1, Sommersemester 2020\n' );
fprintf( 'Uebungsblatt 9, Aufgabe 39: Bisektionsverfahren\n\n' );

% Definition der Funktions-Handle
f1 = @(x) x .^ 2 - 2;
f2 = @(x) sin( x ) - cos( 2 * x );
f3 = @(x) x .^ 3 - 7 * x .^ 2 + 6;
f4 = @(x) 500 * x;
f5 = @(x) 0.00001 * x;

% Loesung der Gleichungen mit dem Bisektionsverfahren ---------------------
[ a1, b1 ] = bisektion( f1, 1, 3 );
[ a2, b2 ] = bisektion( f2, 0, 1 );
[ a3, b3 ] = bisektion( f3, 2.7, 6.5 );
[ a4, b4 ] = bisektion( f4, -2, 4 );
[ a5, b5 ] = bisektion( f5, -2, 4 );