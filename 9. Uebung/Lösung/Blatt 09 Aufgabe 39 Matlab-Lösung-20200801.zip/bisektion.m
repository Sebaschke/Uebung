function [ a, b ] = bisektion( f, a, b )
% Angewandte Numerik 1, SoSe 2020
% Uebungsblatt 9, Aufgabe 39: Bisektionsverfahren
%
% Berechnet fuer eine stetige Funktion f mit f(a)*f(b)<0 
% nach der Bisektions-Methode eine Nullstelle.
%   Input:  f       Stetige Funktion f(x) mit f(a)*f(b) < 0 
%                   (function handle)
%           a       1. Intervallgrenze
%           b       2. Intervallgrenze
%   Output: a       1. Intervallgrenze des auf 2 Kommastellen bestimmten
%                   Intervalls
%           b       2. Intervallgrenze des auf 2 Kommastellen bestimmten
%                   Intervalls
%
% Letzte Aenderung: 21.06.2020

  % Initialisierung -------------------------------------------------------
  fa    = f(a);
  
  % Zieltoleranz des Intervalls
  tol1  = 0.01;
  
  % Zieltoleranz des Funktionswerts f(x)
  tol2  = 0.01;
  
  % Ausreichende Toleranz des Funktionswerte
  % (auch wenn die Zieltoleranz des Intervalls noch nicht erreicht ist
  tol3  = eps;
  
  % Maximale Anzahl der Iterationen
  maxIt = 1000;
  
  % Name der Funktion
  fnam  = inputname(1);
  
  % Definition der Funktion
  funk  = extractAfter( func2str( f ), '@(x)' );
  
  % Ausgabe der Eingaben
  fprintf( '\nFunktion %s = %s im Intervall [ %4.2f, %4.2f ]\n\n', ...
    fnam, funk, a, b )

  % Fehlerbehandlung ------------------------------------------------------
  % Bedingung f(a)*f(b) < 0 erfuellt?
  if( f( ( a + b) / 2 ) ~= 0 && fa*f(b) >= 0 )
    fprintf( 2, ['Bisektion: Funktion %s erfuellt Bedingung ', ...
      '%s(a)*%s(b)<0 nicht !\n\n'], fnam, fnam, fnam );
    a = NaN;
    b = NaN;
    return;
  end
  
  % Bestimmung der Nullstelle der Funktion f(x) ---------------------------
  for k = 1:maxIt
    m    = ( a + b ) / 2;
    fm   = f(m);
    if ( fa * fm < 0 )
      % Nullstelle in linker Haelfte
      b  = m;
    else
      % Nullstelle in rechter Haelfte
      a  = m;
      fa = fm;
    end
    x  = ( a + b ) / 2;
    fx = f( x );
    fprintf( ['Intervall: [ %7.5f, %7.5f ], Fehler: %7.5f, ', ...
      'x = %8.5f, %s(x) = %10.4g\n'], a, b, b - a, x, fnam, fx );
    if( ( abs( b - a ) < tol1 && abs( fx ) < tol2 ) || abs( fx ) < tol3 )
      break;
    end
  end
  fprintf( 'Anzahl der Iterationen: %d\n\n', k );  
end