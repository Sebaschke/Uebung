function c = condr( A )
% Funktion condr berechnet die Kondition einer Matrix richtig
%
% Input:  A     Matrix, deren Kondition bestimmt werden soll
% Output: c     Kondition der Matrix
%
% Letzte Aenderung: 17.06.2020

  wrnid1 = 'MATLAB:singularMatrix';
  wrnid2 = 'MATLAB:nearlySingularMatrix';
  [m,n] = size( A );
  if( m == n )
    % n x n Matrix
    warning( 'off', wrnid1 );
    warning( 'off', wrnid2 );
    c = norm( A ) * norm( A^-1 );
    warning( 'on', wrnid1 );
    warning( 'on', wrnid2 );
  else
    % m x n Matrix
    s = svd( A );
    % Singulaere Matrizen behandeln
    if any(s == 0)
      c = Inf;
    else
      c = s(1) / s(end);
    end
  end
end