% Angewandte Numerik 1, SoSe 2020
% Uebungsblatt 08, Aufgabe 33
%
% Gestoertes Lineares Ausgleichsproblem und die Normalengleichungen
%
% Letzte Aenderung: 17.06.2020

% Cleanup
clear
close all
clc

fprintf('\nAngewandte Numerik 1, Sommersemester 2020\n');
fprintf('Uebungsblatt 8, Aufgabe 33\n\n');

% Matrix A
A = [1, 1; 1e-5, 0; 0, 1e-5];
fprintf( 'Matrix A:\n' );
disp( A );
cA = condr(A);
fprintf('Kondition der Matrix A: %e\n', cA);

% Normalengleichung A' * A
ATA  = A' * A;
fprintf( '\nMatrix A''*A:\n' );
disp( ATA );
cATA = condr(ATA);
fprintf('Kondition der Matrix A''*A: %e\n', cATA);

% Stoerung der Normalengleichung
DATA = [-1e-10, 0; 0, -1e-10];
fprintf( '\nStoerung Delta( A''*A):\n' );
disp( DATA );

% Gestoerte Normalengleichung
GATA = ATA + DATA;
fprintf( '\nGestoerte Matrix ( A''*A) + Delta( A''*A):\n' );
disp( GATA );
cGATA = condr(GATA);
fprintf('Kondition der gestoerten Matrix A''*A + Delta A''*A: %e\n', ...
  cGATA);

% Stoerung der Normalengleichung mit unterschiedlichen Stoerungen
fprintf( '\nStoerung der Matrix A''*A mit unterschiedlichen ' );
fprintf( 'Matrizen eye(2)*10^(-i)\n' );
for i = 8:15
  GATA  = ATA - eye(2) * 10^(-i);
  cGATA = condr(GATA);
  fprintf( 'i = %2d: Kondition der gestoerten Matrix ', i );
  fprintf( 'A''A - eye(2)*10^-i: %e\n', cGATA );
end