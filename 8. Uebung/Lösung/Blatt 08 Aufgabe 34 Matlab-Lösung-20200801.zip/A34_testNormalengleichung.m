% Angewandte Numerik 1, SoSe 2020
% Uebungsblatt 08, Aufgabe 34: Kondition und Normalengleichungen
%
% Berechnet  mit dem Backslash-Operator (x = An\bn), mit Hilfe
% der Normalengleichungen und mit Hilfe der QR-Zerlegung jeweils
% eine Naeherungsloesung des linearen Ausgleichsproblems 
% ||A_n*x - b_n|| --> min
%
% Letzte Aenderung: 23.06.2020

% Cleanup
clearvars;
close all;
clc;

% Initialisierung ---------------------------------------------------------
fprintf( '\nAngewandte Numerik 1, Sommersemester 2020\n' );
fprintf ...
  ( 'Uebungsblatt 8, Aufgabe 34: Kondition und Normalengleichungen\n\n' );

% Identifier von Matlab Warnungen
wrnid1 = 'MATLAB:rankDeficientMatrix';
wrnid2 = 'MATLAB:nearlySingularMatrix';

% Minimaler Fehler, um 0-Werte logarithmisch zu plotten
miner = 1e-18;

% Obere Grenze der Laufvariable
nmax  = 13;

% Initialisieren der Vektoren
errbs = zeros( 1, nmax );
errqr = zeros( 1, nmax );
errNg = zeros( 1, nmax );
nvals = 1:nmax;

% Berechnung der Naeherungsloesungen des linearen Ausgleichsproblems ------
for n = nvals
  fprintf( 'n = %2d\n', n );
  % Doppelte Hilbertmatrix
  An = [hilb(n); hilb(n)];
  
  % Exakter x-Wert und daraus berechneter b-Vektor
  xn = rand(n,1);
  bn = An * xn;

  % Backslash Operator
  warning( 'off', wrnid1 );
  xbs      = An \ bn;
  warning( 'on', wrnid1 );
  errbs(n) = norm( xbs - xn ) / norm( xn );
  
  % QR-Zerlegung
  [q,r]    = qr( An );
  warning( 'off', wrnid1 );
  xqr      = q * r \ bn;
  warning( 'on', wrnid1 );
  errqr(n) = norm( xqr - xn ) / norm( xn );
  
  % Normalengleichung
  warning( 'off', wrnid2 );
  Ng = An' * An;
  xNg = Ng \ An' * bn;
  warning( 'on', wrnid2 );
  errNg(n) = norm( xNg - xn ) / norm( xn );
  
  fprintf( '   Kondition von An: %8.3g, Kondition von An''*An: %8.3g\n',                                ...
    cond(An), cond(Ng) );
end

% Plotten der relativen Fehler --------------------------------------------
hf1 = figure( 'Name', 'Angewandte Numerik 1, Blatt 8, Aufgabe 34',  ...
  'NumberTitle', 'off', 'Units', 'normalized', 'MenuBar', 'None',   ...
  'Position', [0.15, 0.1, 0.70, 0.85] );

% Um 0-Werte logarithmisch zu plotten
errNg(errNg==0) = miner;
errqr(errqr==0) = miner;
% Backslash Operator
semilogy( nvals, errbs, 'bo-', 'Display', 'Backslash Operator', ...
  'LineWidth', 2 );
hold on;
% QR-Zerlegung
semilogy( nvals, errqr, 'gd-', 'Display', 'QR-Zerlegung', ...
  'LineWidth', 2 );
% Normalengleichung
semilogy( nvals, errNg, 'r*-', 'Display', 'Normalengleichung', ...
  'LineWidth', 2 );
hold off;

% Achsen, Label, Legende und Titel
xticks( nvals );
ylim( [ miner, 30 ] );
xlabel( 'n-Werte', 'FontSize', 14 );
ylabel( 'Relative Fehler', 'FontSize', 14 );
legend( 'show', 'Location', 'NorthWest', 'FontSize', 14 );
title( 'Fehler der Naeherungsloesungen des linearen Ausgleichsproblems',...
  'FontSize', 20 );