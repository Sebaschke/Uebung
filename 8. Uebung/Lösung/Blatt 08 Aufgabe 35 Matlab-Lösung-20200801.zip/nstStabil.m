function [ x1, x2 ] = nstStabil( pVec, q )
% Angewandte Numerik 1, SoSe 2020
% Uebungsblatt 08, Aufgabe 34: Kondition und Stabilitaet
%
% Die Funktion [ x1, x2 ] = nstStabil( pVec, q ) berechnet
% die Loesungen x1 und x2, x1 <= x2, der quadratischen Gleichung
% f(x) = x.^2 + 2px - q fuer p^2 - q >= 0
% fuer verschiedene Werte von p ohne Ausloeschung, also stabil.
%
% Ist die Bedingung p^2 + q >= 0 nicht erfuellt, d.h. es treten
% komplexe Wurzeln auf, so werden die entsprechenden Werte
% x1 und x2 auf NaN gesetzt.
%
% Input:  pVec  Vektor, viele Werten fuer p
%         q     Skalar, ein Wert fuer q
%
% Output: x1    Vektor mit den pVec entsprechenden Werten der Loesung x1
%         x2    Vektor mit den pVec entsprechenden Werten der Loesung x2

  % Vektoren x1 und x2 initialisieren
  x1 = zeros(size(pVec));
  x2 = zeros(size(pVec));
  
  % Wert unter der Wurzel
  sr = ( pVec .^ 2 ) + q;

  % x1 und x2 fuer positive p berechnen
  ind     = find( pVec > 0 );
  x1(ind) = - pVec(ind) - sqrt( sr(ind) );
  x2(ind) = - q ./ x1(ind);

  % x1 und x2 fuer negative p und fuer p == 0 berechnen
  ind     = find(pVec <= 0);
  x2(ind) = - pVec(ind) + sqrt( sr(ind) );
  x1(ind) = - q ./ x2(ind);

  % Ersetze komplexe Wurzeln durch NaN
  x1(sr < 0) = NaN;
  x2(sr < 0) = NaN;
end