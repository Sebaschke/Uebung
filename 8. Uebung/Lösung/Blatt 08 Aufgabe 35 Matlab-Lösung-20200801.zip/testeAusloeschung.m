function testeAusloeschung( x, p )
% Angewandte Numerik 1, SoSe 2020
% Uebungsblatt 08, Aufgabe 35: Kondition und Stabilitaet
%
% Die Funktion testeAusloeschung( x, p ) prueft, ob und,
% wenn ja, fuer welche p Ausloeschung aufgetreten ist.
%
% Input:  x    Vektor mit den berechneten Nullstellen
%         p    Vektor mit den zugehoerigen Werten von p
% Output:      Keine Ausgabe

  % Gewaehlte Toleranz, nur 11 von 53 Bits sind korrekt
  tol = 2^11 * eps;               
                                  
  % Index der Nullstellen mit Ausloeschung
  ind = find(abs(x) < tol);

  if isempty(ind)
    fprintf(' keine Ausloeschung!\n')
  else
    minInd   = min(ind);
    maxInd   = max(ind);
    grenzInd = ind( find(ind(2:end)-ind(1:end-1)-1, 1, 'last')+1 );
    if isempty(grenzInd)
      fprintf('\n   Ausloeschung tritt auf fuer alle Werte von p ');
      fprintf('zwischen %g und %g,\n', p(minInd), p(maxInd));
    else
      fprintf('\n   Ausloeschung tritt auf fuer Werte von p ');
      fprintf('zwischen %g und %g,\n', p(minInd), p(maxInd));
      fprintf('   Ab p = %g sind alle x von Ausloeschung betroffen.\n', ...
        p(grenzInd));
    end
  end
end