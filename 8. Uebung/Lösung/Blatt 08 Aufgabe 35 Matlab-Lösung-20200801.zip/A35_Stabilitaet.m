% Angewandte Numerik 1, SoSe 2020
% Uebungsblatt 08, Aufgabe 35: Unterschied Kondition und Stabilitaet
%
% Berechnet die Nullstellen x1 <= x2 der quadratischen Funktion 
% f(x) = x^2 + 2px - q fuer p^2 - q >= 0, q > 0
% mit einem nicht stabilen und einem stabilen Algorithmus
% und plottet die jeweiligen relativen Fehler.
%
% Mit den Bedingungen p^2 - q >= 0, q > 0 ist die Berechnung der 
% Nullstellen gut konditioniert

% Cleanup
clearvars;
close all;
clc;

% Initialisierungen -------------------------------------------------------
fprintf( '\nAngewandte Numerik 1, Sommersemester 2020\n' );
fprintf( 'Uebungsblatt 8, Aufgabe 35: Kondition und Stabilitaet\n\n' );

% Maximale Zehnerpotenz fuer p
maxT   = 12;
% Schrittweite der t-Werte
deltaT = 0.01;

% 2. Parameter der quadratischen Funktion
q      = 1;

% Initialisierung der Vektoren
alleTs = 0:deltaT:maxT;     % Zeilenvektor mit allen Werten fuer t
allePs = 10.^alleTs;        % Zeilenvektor mit allen Werten fuer p
anzPs  = length(allePs);    % Anzahl der Werte


fprintf('Betragsmaessig kleinster Wert fuer p: %g\n', min(allePs));
fprintf('Betragsmaessig groesster Wert fuer p: %g\n', max(allePs));
fprintf('Schrittweite fuer die Werte von p:    %g\n', deltaT);
fprintf('Wert von q:                           %g\n\n\n', q);

% Nicht stabile Berechnung der Nullstellen --------------------------------

[x1pPos, x2pPos] = nst( allePs, q);       	          % fuer positive p
[x1pNeg, x2pNeg] = nst(-allePs, q);                   % fuer negative p

fprintf('Nicht stabile Berechnung der Nullstellen:\n');
fprintf('---------------------------------------------------------\n\n');

fprintf('Ausloeschung bei x1 fuer positive p:');
testeAusloeschung(x1pPos, allePs);

fprintf('\nAusloeschung bei x2 fuer positive p:');
testeAusloeschung(x2pPos, allePs);

fprintf('\nAusloeschung bei x1 fuer negative p:');
testeAusloeschung(x1pNeg, -allePs);

fprintf('\nAusloeschung bei x2 fuer negative p:');
testeAusloeschung(x2pNeg, -allePs);

% Stabile Berechnung der Nullstellen --------------------------------------

[x1pPosStabil, x2pPosStabil] = nstStabil( allePs, q); % fuer positive p
[x1pNegStabil, x2pNegStabil] = nstStabil(-allePs, q); % fuer negative p

fprintf('\n\nStabile Berechnung der Nullstellen:\n');
fprintf('---------------------------------------------------------\n\n');

fprintf('Ausloeschung bei x1 fuer positive p:');
testeAusloeschung(x1pPosStabil, allePs);

fprintf('\nAusloeschung bei x2 fuer positive p:');
testeAusloeschung(x2pPosStabil, allePs);

fprintf('\nAusloeschung bei x1 fuer negative p:');
testeAusloeschung(x1pNegStabil, -allePs);

fprintf('\nAusloeschung bei x2 fuer negative p:');
testeAusloeschung(x2pNegStabil, -allePs);
fprintf('\n');

% Relative Fehler berechnen -----------------------------------------------

% Relative Fehler von x1 und x2 fuer positive p
errRelX1pPos = abs( (x1pPosStabil-x1pPos)./x1pPosStabil );
errRelX2pPos = abs( (x2pPosStabil-x2pPos)./x2pPosStabil );

% Relative Fehler von x1 und x2 fuer negative p
errRelX1pNeg = abs( (x1pNegStabil-x1pNeg)./x1pNegStabil );
errRelX2pNeg = abs( (x2pNegStabil-x2pNeg)./x2pNegStabil );

% Relative Fehler plotten -------------------------------------------------

hf1 = figure( 'Name', 'Angewandte Numerik 1, Blatt 8, Aufgabe 35',  ...
  'NumberTitle', 'off', 'Units', 'normalized', 'MenuBar', 'None',   ...
  'Position', [0.01, 0.1, 0.98, 0.80] );
sgtitle( 'Loesung einer quadratischen Gleichung', 'FontSize', 22 );

% Titel
titleStr = '{x^2}+2px - q = 0';

% Bestimmung der Subplots
sp = sum( [ max(errRelX1pPos) > 0, max(errRelX2pPos) > 0, ...
            max(errRelX1pNeg) > 0, max(errRelX2pNeg) > 0 ] );
spelement = 0;
spZeilen  = 1;
spSpalten = sp;
if( sp > 3 )
  spZeilen  = 2;
  spSpalten = 2;
end

% Relative Fehler von x1 fuer positive p
if max(errRelX1pPos) > 0
  spelement = spelement + 1;
  subplot( spZeilen, spSpalten, spelement );

  loglog(allePs, errRelX1pPos, '-');
  title(sprintf('%s mit p > 0 und q = %g', titleStr, q), 'FontSize', 17);
  xlabel('p', 'FontSize', 14);
  ylabel('relativer Fehler in x1', 'FontSize', 14);
  ylim([1e-17, 1e1]);
end

% Relative Fehler von x2 fuer positive p
if max(errRelX2pPos) > 0
  spelement = spelement + 1;
  subplot( spZeilen, spSpalten, spelement );
  loglog(allePs, errRelX2pPos, '-');
  title(sprintf('%s mit p > 0 und q = %g', titleStr, q), 'FontSize', 17);
  xlabel('p', 'FontSize', 14);
  ylabel('relativer Fehler in x2', 'FontSize', 14);
  ylim([1e-17, 1e1]);
end

% Relative Fehler von x1 fuer negative p
if max(errRelX1pNeg) > 0
  spelement = spelement + 1;
  subplot( spZeilen, spSpalten, spelement );
  loglog(allePs, errRelX1pNeg, '-');
  title(sprintf('%s mit p < 0 und q = %g', titleStr, q), 'FontSize', 17);
  xlabel('|p|', 'FontSize', 14);
  ylabel('relativer Fehler in x1', 'FontSize', 14);
  ylim([1e-17, 1e1]);
end

% Relative Fehler von x2 fuer negative p
if max(errRelX2pNeg) > 0
  spelement = spelement + 1;
  subplot( spZeilen, spSpalten, spelement );
  loglog(allePs, errRelX2pNeg, '-');
  title(sprintf('%s mit p < 0 und q = %g', titleStr, q), 'FontSize', 17);
  xlabel('|p|', 'FontSize', 14);
  ylabel('relativer Fehler in x2', 'FontSize', 14);
  ylim([1e-17, 1e1]);
end