% Angewandte Numerik 1, SoSe 2020
% Uebungsblatt 06, Aufgabe 22a, Vergleich der Rechenzeiten
%
% Das Skript laufzeiten22a_14 bestimmt die Rechenzeit der LR-Zerlegung
% einer Tridiagonalmatrix A in Abhaengigkeit von der Dimension 
% n in {2^i | i = 3, ..., 14} dieser Matrix.
%

% Cleanup -----------------------------------------------------------------
clearvars;
clc;
close all;

% Initialisierung ---------------------------------------------------------
ulim          = 3;
olim          = 12;
nvals         = zeros( 1, olim - ulim + 1 );
LR_TriDiagTim = zeros( 1, olim - ulim + 1 );

% Warmup-Code
c = 0;
for i = 1:100
   z = rand(i,i);
   c = c + size(z, 1);
end

% LR-Zerlegung fuer unterschiedliche Dimensionen der Tridiagonalmatrix ----
for j = ulim:olim
  n = 2^j;
  fprintf('n = %5d\n', n);
  nvals(j-ulim+1) = n;
  nd = -ones(n-1,1);
  ad = 2 * ones(n,1);
  %A  = diag(nd,1) + diag(ad) + diag(nd,-1);
  tic
  [ lnd, rd, rnd ] = LR_TriDiag( nd, ad, nd );
  LR_TriDiagTim(j-ulim+1) = toc;
end

% Bestimmung der Steigungsgerade (Ausgleichsgerade ab 6. Datenpunkt) ------
m=6;
% Beide Variable logarithmieren
X = log10( nvals(m:end) );
Y = log10( LR_TriDiagTim(m:end) );
% Koeffizienten der Steigungsgerade bestimmen
b = polyfit( X, Y, 1 );
% Berechnung der Werte an den Endpunkten der Gerade
x = [ nvals(m), nvals(end) ];
y = 10.^( b(1) * log10( x ) + b(2) );
% Text fuer die Legende
t = ['Steigungsgerade von LR\_TriDiag, m = ', num2str( b(1), 2 )];

% Grafikausgabe -----------------------------------------------------------
hf1 = figure( 'Name', 'Angewandte Numerik 1, Blatt 6, Aufgabe 22',  ...
  'NumberTitle', 'off', 'Units', 'normalized', 'MenuBar', 'None',   ...
  'Position', [0.02, 0.1, 0.96, 0.8] );

% Rechenzeiten ueber der Dimension der Tridiagonalmatrix plotten
loglog( nvals, LR_TriDiagTim, '*-r', 'Display', 'LR\_TriDiag', ...
  'LineWidth', 1.5);

% Steigungsgerade anfuegen
hold on;
loglog( x, y, '-c', 'Display', t, 'LineWidth', 1.5);
hold off;

% Achsenbeschriftungen, Legende, Titel
xlim( [ 7, nvals(end)*1.1 ] );
xlabel( 'Dimension der Tridiagonalmatrix', 'FontSize', 15 );
ylabel( 'Rechenzeit in Sekunden', 'FontSize', 15 );
xticks( nvals );
xlab = cellstr( string( nvals ) );
xticklabels( xlab );
legend( 'show', 'Location', 'NorthWest', 'FontSize', 15 );
title ...
  ('Rechenzeit der LR-Zerlegung versus Dimension der Tridiagonalmatrix',...
  'FontSize', 20 );