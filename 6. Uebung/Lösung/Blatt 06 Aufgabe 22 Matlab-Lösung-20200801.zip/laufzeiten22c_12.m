% Angewandte Numerik 1, SoSe 2020
% Uebungsblatt 06, Aufgabe 22c, Vergleich der Rechenzeiten
%
% Das Skript laufzeiten22c_12 bestimmt die Rechenzeit der LR-Zerlegung
% einer Tridiagonalmatrix A in Abhaengigkeit von der Dimension 
% n in {2^i | i = 3, ..., 12} dieser Matrix.
% Zur LR-Zerlegung wird einerseits die fuer Tridiagonalmatrizen optimierte
% Function LR_TriDiag verwendet, andererseits die normale LR-Zerlegung
% mit spaltenweisem  oder zeilenweisem Matrixzugriff und 1-3 Schleifen.

% Cleanup -----------------------------------------------------------------
clearvars;
clc;
close all;

% Initialisierung ---------------------------------------------------------
ulim          = 3;
olim          = 12;
nvals         = zeros( 1, olim - ulim + 1 );

% Initialisierung der Vektoren
LR_TriDiagTim = zeros( 1, olim - ulim + 1 );
LR_gaussS1Tim = zeros( 1, olim - ulim + 1 );
LR_gaussS2Tim = zeros( 1, olim - ulim + 1 );
LR_gaussS3Tim = zeros( 1, olim - ulim + 1 );
LR_gaussZ2Tim = zeros( 1, olim - ulim + 1 );
LR_gaussZ3Tim = zeros( 1, olim - ulim + 1 );

% LR-Zerlegung fuer unterschiedliche Dimensionen der Tridiagonalmatrix ----
for j = ulim:olim
  n = 2^j;
  fprintf('n = %5d\n', n);
  nvals(j-ulim+1) = n;
  nd = -ones(n-1,1);
  ad = 2 * ones(n,1);
  A  = diag(nd,1) + diag(ad) + diag(nd,-1);
  
  % LR-Zerlegung fuer Tridiagonalmatrizen
  tic
  [ ~, ~, ~ ] = LR_TriDiag( nd, ad, nd );
  LR_TriDiagTim(j-ulim+1) = toc;
  
  % LR-Zerlegung gaussLR: Spaltenweiser Matrixzugriff, 1 Schleife
  tic
  [ ~, ~ ] = gaussLR_S1( A );
  LR_gaussS1Tim(j-ulim+1) = toc;
  
  % LR-Zerlegung gaussLR: Spaltenweiser Matrixzugriff, 2 Schleifen
  tic
  [ ~, ~ ] = gaussLR_S2( A );
  LR_gaussS2Tim(j-ulim+1) = toc;
  
  % LR-Zerlegung gaussLR: Spaltenweiser Matrixzugriff, 3 Schleifen
  tic
  [ ~, ~ ] = gaussLR_S3( A );
  LR_gaussS3Tim(j-ulim+1) = toc;
  
  % LR-Zerlegung gaussLR: Zeilenweiser Matrixzugriff, 2 Schleifen
  tic
  [ ~, ~ ] = gaussLR_Z2( A );
  LR_gaussZ2Tim(j-ulim+1) = toc;
  
  % LR-Zerlegung gaussLR: Zeilenweiser Matrixzugriff, 3 Schleifen
  tic
  [ ~, ~ ] = gaussLR_Z3( A );
  LR_gaussZ3Tim(j-ulim+1) = toc;  
end

% Steigungsgeraden (Ausgleichsgeraden) ------------------------------------
% Steigungsgerade: LR-Zerlegung fuer Tridiagonalmatrizen
% Ausgleichsgerade ab 6. Datenpunkt
m=6;
% Beide Variable logarithmieren
X = log( nvals(m:end) );
Y = log( LR_TriDiagTim(m:end) );
% Koeffizienten der Steigungsgerade bestimmen
b = polyfit( X, Y, 1 );
% Berechnung der Werte an den Endpunkten der Gerade
x = [ nvals(m), nvals(end) ];
y = exp( b(1) * log( x ) + b(2) );
% Text fuer die Legende
t = ['Steigungsgerade von LR\_TriDiag, m = ', num2str( b(1), 2 )];

% Steigungsgerade: gaussLR: Spaltenweiser Matrixzugriff, 3 Loops ----------
% Ausgleichsgerade ab 4. Datenpunkt
m=4;
% Beide Variable logarithmieren
X3 = log( nvals(m:end) );
Y3 = log( LR_gaussS3Tim(m:end) );
% Koeffizienten der Steigungsgerade bestimmen
b3 = polyfit( X3, Y3, 1 );
% Berechnung der Werte an den Endpunkten der Gerade
x3 = [ nvals(m), nvals(end) ];
y3 = exp( b3(1) * log( x3 ) + b3(2) );
% Text fuer die Legende
t3 = ['Steigungsgerade von gaussLR\_S3, m = ', num2str( b3(1), 2 )];

% Grafikausgabe -----------------------------------------------------------
hf1 = figure( 'Name', 'Angewandte Numerik 1, Blatt 5, Aufgabe 22',  ...
  'NumberTitle', 'off', 'Units', 'normalized', 'MenuBar', 'None',   ...
  'Position', [0.02, 0.1, 0.96, 0.8] );

% Rechenzeiten plotten: LR-Zerlegung fuer Tridiagonalmatrizen
loglog( nvals, LR_TriDiagTim, '*-r', 'Display', 'LR\_TriDiag', ...
  'LineWidth', 1.5 );
hold on;

% Steigungsgerade anfuegen: LR-Zerlegung fuer Tridiagonalmatrizen
loglog( x, y, '-c', 'Display', t, 'LineWidth', 1.5 );

% Rechenzeiten plotten: gaussLR: Spaltenweiser Matrixzugriff, 1 Loop
loglog( nvals, LR_gaussS1Tim, 'd-m', 'Display', ...
  'gaussLR\_S1: spaltenweise, 1 Loop', 'LineWidth', 1.5 );

% Rechenzeiten plotten: gaussLR: Spaltenweiser Matrixzugriff, 2 Loops
loglog( nvals, LR_gaussS2Tim, 'x-g', 'Display', ...
  'gaussLR\_S2: spaltenweise, 2 Loops', 'LineWidth', 1.5 );

% Rechenzeiten plotten: gaussLR: Spaltenweiser Matrixzugriff, 3 Loops
loglog( nvals, LR_gaussS3Tim, '+-b', 'Display', ...
  'gaussLR\_S3: spaltenweise, 3 Loops', 'LineWidth', 1.5 );
% Steigungsgerade anfuegen: gaussLR: Spaltenweiser Matrixzugriff, 3 Loops
loglog( x3, y3, '-r', 'Display', t3, 'LineWidth', 1.5 );

% Rechenzeiten plotten: gaussLR: Zeilenweiser Matrixzugriff, 2 Loops
loglog( nvals, LR_gaussZ2Tim, 's-k', 'Display', ...
  'gaussLR\_Z2: zeilenweise, 2 Loops', 'LineWidth', 1.5 );

% Rechenzeiten plotten: gaussLR: Zeilenweiser Matrixzugriff, 3 Loops
loglog( nvals, LR_gaussZ3Tim, 'o-c', 'Display', ...
  'gaussLR\_Z3: zeilenweise, 3 Loops', 'LineWidth', 1.5 );
hold off;

% Achsenbeschriftungen, Legende, Titel
xlabel( 'Dimension der Tridiagonalmatrix', 'FontSize', 15 );
ylabel( 'Rechenzeit in Sekunden', 'FontSize', 15 );
xlim( [ 7, 4200 ] );
xticks( nvals );
xlab = cellstr( string( nvals ) );
xticklabels( xlab );
legend( 'show', 'Location', 'NorthWest', 'FontSize', 14 );
set( legend, 'NumColumns', 2 )
title( 'Rechenzeit der LR-Zerlegung in Abhaengigkeit von der Dimension', ...
  'FontSize', 20 );