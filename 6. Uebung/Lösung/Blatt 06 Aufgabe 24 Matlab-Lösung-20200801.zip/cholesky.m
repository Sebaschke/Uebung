function [ L, D ] = cholesky( A )
% Angewandte Numerik 1, SoSe 2020
% Uebungsblatt 06, Aufgabe 24: Cholesky-Zerlegung
%
% Die Function [ L, D ] = cholesky_vec( A ) berechnet die Cholesky-
% Zerlegung A = L*D*L' einer gegebenen symmetrisch positiv definiten
% Matrix A mit 2 Schleifen.
% 
% Input:  A   Gegebene nxn symmetrisch positiv definite Matrix, deren
%             Cholesky-Zerlegung berechnet werden soll
% Output: L   n x n linke, untere, normierte Dreiecksmatrix
%         D   Diagonalmatrix mit positiven Diagonaleintraegen der 
%             Cholesky-Zerlegung
%
% Letzte Aenderung: 02.06.2020

  % Fehlerbehandlung ------------------------------------------------------
  % Ueberpruefen, ob die Matrix symmetrisch ist
  if ( ~all( A == A', 'all') )
    fprintf( 2, 'Die Eingabe-Matrix ist nicht symmetrisch !\n' );
    % Leere Matrizen als Rueckgabewerte im Fehlerfall
    L = [];
    D = [];
    return
  end

  % Initialisierung -------------------------------------------------------
  % Dimension der Matrix
  n = size( A, 1 );
  L = eye( n );
  d = zeros( n, 1 );
  
  % Cholesky Zerlegung ----------------------------------------------------
  % Arbeite auf der k-ten Spalte
  for k = 1:n
    % Berechne die Komponente D(k,k)
    d(k) = A(k,k) - L(k,1:k-1).^2 * d(1:k-1);
    
    % Ueberpruefen, ob die Matrix symmetrisch positiv definit ist
    if ( d(k) <= 0 )
      fprintf( 2, 'Matrix ist nicht symmetrisch positiv definit ! ' );
      fprintf( '(Spalte %d)\n', k );
      % Leere Matrizen als Rueckgabewerte im Fehlerfall
      L = [];
      D = [];
      return
    end
        
    % j-te Zeile bearbeiten
    for j = k+1:n
      % Berechne die L(j,k)-Komponenten der L Matrix
      L(j,k) = ( A(j,k) - ...
        L(j,1:k-1) * ( d(1:k-1) .* L(k,1:k-1)' ) ) ./ d(k);
    end
  end
  D = diag( d );
end