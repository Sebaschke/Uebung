% Angewandte Numerik 1, SoSe 2020
% Uebungsblatt 06, Aufgabe 24b: Cholesky-Zerlegung
%
% Testprogramm fuer die Funktionen [ L, D ] = cholesky( A ) oder
% [ L, D ] = choleskyL1( A ):
% Berechnung der Cholesky-Zerlegung einer symmetrisch positiv definiten
% MAtrix A, so dass A = L*D*L'.
%
% Letzte Aenderung: 02.06.2020

% Cleanup
clear;
close all;
clc;

% Initialisierungen -------------------------------------------------------
fprintf('\nAngewandte Numerik 1, Sommersemester 2020\n');
fprintf('Uebungsblatt 6, Aufgabe 24b: Cholesky-Zerlegung\n');
fprintf('\nTeste Berechnungen der Cholesky-Zerlegung\n\n');

% Fehlertoleranz
tol = 1e-14;

% Verwendete Function zur Cholesky-Zerlegung
myChol = @choleskyL1;

% Untersuchung der Testfaelle ---------------------------------------------
for bsp = 1:8
  switch bsp
    case 1                             % Testfall 1
      A = [ 1 -1  0; ...               % nicht symmetrisch
           -1  1  1; ...
            0 -1  2 ];
    case 2                             % Testfall 2
      A = [ 1  2  1; ...               % nicht symmetrisch positiv definit
            2  1  1; ...
            1  1 -2 ];
    case 3                             % Testfall 3
      A = [ 1  2  1; ...
            2  8  2; ...
            1  2  2 ];
    case 4                             % Testfall 4
      A = [ 2  6 -2; ...
            6 21  0; ...
           -2  0 16 ];
    case 5                             % Testfall 5
      A = hilb(10);
    case 6                             % Testfall 6
      A = [ 2  6 -2; ...               % nicht symmetrisch
            6 21  0; ...
           -5  0 16 ];
    case 7                             % Testfall 7
      A = rand( 35 );
      A = A + A' + 10 * eye( 35 );
    case 8
      A = [ 2  6 -2; ...
            6 21  0; ...
           -2  0 16 ];
    otherwise
      break;                           % keine Testfaelle mehr vorhanden
  end
  
  % Testfall berechnen: Cholesky-Zerlegung ausfuehren ---------------------
  [ L, D ] = myChol(A);

  % Ueberpruefen, ob die Cholesky-Zerlegung erfolgreich war ---------------
  if( numel( L ) == 0 )
    fprintf( 2, 'Testcase %d: Failed\n\n', bsp );
  else
    % Ueberpruefen, ob die Cholesky-Zerlegung fehlerfrei ist
    err = max(abs( L * D * L' - A ), [], 'all' );
    if (err < tol)
      fprintf( 'Testcase %d: Passed\n\n', bsp );
    else
      fprintf( 2, 'Testcase %d: Failed\n\n', bsp );
    end
  end
end