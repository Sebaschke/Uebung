function [ lnd, rd, rnd ] = LR_TriDiag( aUnd, ad, aOnd )
% Angewandte Numerik 1, SoSe 2020
% Uebungsblatt 06, Aufgabe 21: LR-Zerlegung f�r Tridiagonalmatrizen
%
% Die Function [ lnd, rd, rnd ] = LR_TriDiag( aUnd, ad, aOnd ) berechnet
% die LR-Zerlegung einer quadratischen Tridiagonal-Matrix A ohne
% Pivotisierung
%
% Input:  aUnd  Untere Nebendiagonale [a(2,1), ..., a(n,n?1)] der Matrix A
%         ad    Diagonale [a(1,1), ..., a(n,n)] der Matrix A
%         aOnd  Obere Nebendiagonale [a(1,2), ..., a(n?1,n)] der Matrix A
% Output: lnd   Untere Nebendiagonale [l(2,1), ..., l(n,n?1)] der Matrix L
%         rd    Diagonale [r(1,1), ..., r(n,n)] der Matrix R
%         rnd   Obere Nebendiagonale [r(1,2), ..., r(n?1,n)] der Matrix R 
%
% Letzte Aenderung: 30.05.2020
  
  % Fehlerbehandlung
  if( any( ad(1:end-1) == 0 ) )
    fprintf( 2, 'LR Zerlegung existiert nicht !' );
    lnd = NaN;
    rd  = NaN;
    rnd = NaN;
    return;
  end

  % Dimension der Matrix
  n = length( ad );
  
  % Initialisierung der Vektoren
  lnd   = zeros( n-1, 1 );
  rd    = zeros( n, 1 );
  rd(1) = ad(1);
  
  % LR-Zerlegung
  for k = 2:n
    lnd(k-1) = aUnd(k-1) / rd(k-1);
    rd(k)    = ad(k) - lnd(k-1) * aOnd(k-1);
  end
  
  % Bei einer Tridiagonalmatrix bleibt die obere Nebendiagonale bei
  % einer LR-Zerlegung unver�ndert
  rnd = aOnd;
end