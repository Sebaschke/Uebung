% Angewandte Numerik 1, SoSe 2020
% Uebungsblatt 06, Aufgabe 21d, LR-Zerlegung fuer Tridiagonalmatrizen
%
% Das Skript test21d testet die Function LR_TriDiag an verschiedenen
% Beispielen und vergleicht die Ergebnisse mit einer gaussLR Function.
%
% Letzte Aenderung: 01.06.2020

% Cleanup -----------------------------------------------------------------
clearvars;
clc;
close all;

% Initialisierung ---------------------------------------------------------
% Dimension der Matrizen
dim  = [ 295, 467, 719, 980 ];
% Zahlenbereich der Zufallszahlen
fact = [ 20, 40, 15, 35 ];

fprintf('\nAngewandte Numerik 1, Sommersemester 2020\n');
fprintf('Uebungsblatt 6, Aufgabe 21d: LR-Zerlegung fuer ');
fprintf('Tridiagonalmatrizen\n\n');

% LR-Zerlegung fuer unterschiedliche Tridiagonalmatrizen ------------------
for k = 1:length(dim)
  ndo = rand( 1, dim(k)-1 ) * fact(k);
  ad  = rand( 1, dim(k) )   * fact(k);
  ndu = rand( 1, dim(k)-1 ) * fact(k);
  A   = diag( ndo, 1 ) + diag( ad ) + diag( ndu, -1 );
  
  % LR-Zerlegung fuer Tridiagonalmatrizen
  tic
  [ lnd, rd, rnd ] = LR_TriDiag( ndu, ad, ndo );
  LR_TriDiagTim = toc;
  Lt = diag( lnd, -1 ) + eye( dim(k) );
  Rt = diag( rnd, 1 )  + diag( rd );
  
  % LR-Zerlegung gaussLR: Spaltenweiser Matrixzugriff, 3 Schleifen
  tic
  [ L, R ] = gaussLR_S3( A );
  LR_gaussS3Tim = toc;
  
  % Ergebnis
  fprintf('\nFall %d\n', k );
  fprintf('   Laufzeit LR_TriDiag: %8.6f, Laufzeit gaussLR_S3: %8.6f\n',...
    LR_TriDiagTim, LR_gaussS3Tim );
  fprintf('   Fehler der L-Matrix: %8.6g, Fehler der R-Matrix: %8.6g\n',...
    norm( Lt - L ), norm( Rt - R ) );
end