function pt = hornerSchema( a, t )
% Angewandte Numerik 1, SoSe 2020
% Uebungsblatt 11, Aufgabe 49: Horner-Schema
%
% Die Funktion pt = hornerSchema(a, t) wertet Polynome p(x)=sum(a_k*x^k)
% (in der Monombasis-Darstellung) mit den Koeffizienten 
% a = (a_0, a_1, a_2, ..., a_n)'  effizient aus.
%
% Input:  a   Die Koeffizienten des Polynoms, a = (a_0, a_1,a_2, ..., a_n)'
%         t   Vektor der Stellen, an denen das Polynom ausgewertet
%             werden soll, mit t = (t_1, t_2, ..., t_m)
% Output: pt  Vektor der Funktionswerte des durch a gegebenen Polynoms
%             pt = (pt_1, pt_2, ..., pt_m)', ausgewertet an den Stellen t

  % Grad des Polynoms p
  n = length(a) - 1;

  % Horner-Schema ---------------------------------------------------------
  % Ausgabevektor initialisieren und hoechsten Koeefizient eintragen
  pt = a(n+1) * ones(size(t));
  
  % Die restlichen Koeffizienten ablaufen
  for i = n:-1:1
    pt = pt .* t + a(i);
  end
end