% Angewandte Numerik 1, SoSe 2020
% Uebungsblatt 11, Aufgabe 49: Horner-Schema
%
% Testet die Funktion pt = hornerSchema( a, x ) zur effizienten
% Auswertung von verschiedenen Polynomen und vergleicht die 
% Ergebnisse mit der Matlab Funktion polyval.
%
% Letzte Aenderung: 06.07.2020

% Cleanup
clearvars;
close all;
clc;

% Initialisierung =========================================================
fprintf( '\n\nAngewandte Numerik 1, Sommersemester 2020\n' );
fprintf( 'Uebungsblatt 11, Aufgabe 49: Horner-Schema\n\n' );

% Alle Testfaelle abarbeiten ============================================== 
% Schleife ueber alle Testfaelle
for testFall = 1:3
  % Testfaelle definieren -------------------------------------------------
  switch testFall
    case 1
      % Beschreibung
      beschr = 'Interpolationspolynom mit 4 Stuetzstellen x0, ...,x3';
      % Koeffizienten des Polynoms
      a      = [1; 32/27; 2/3; 4/27];
      % Auswerte-Stelle
      t      = 1/2;
      % Loesung
      lsgStr = 'Berechnete Loesung (Exakt: 16/9):';
      pExakt = 16/9;
      
    case 2
      % Beschreibung
      beschr = 'Interpolationspolynom mit 5 Stuetzstellen x0, ...,x4';
      % Koeffizienten des Polynoms
      a      = [1; 28/27; 16/27; 8/27; 2/27];
      % Auswerte-Stelle
      t      = 1/2;
      % Loesung
      lsgStr = 'Berechnete Loesung (Exakt: 41/24):';
      pExakt = 41/24;
    case 3
      % Beschreibung
      beschr = ['Partialsumme der geometrischen Reihe: ', ...
        't^1 + ... + t^30 = (t^31-t)/(t-1)'];
      % Koeffizienten des Polynoms
      a      = [0; ones(30,1)];
      % Auswerte-Stellen
      t      = [1/3; 1/2; 2/3; 2];
      % Exakte  Werte
      lsgStr = 'Exakte Werte der Partialsumme:';
      pExakt = (t.^31-t) ./ (t-1);
    otherwise
      error('Testfall ''%d'' nicht implementiert', testFall);
  end
    
  % Testfall bearbeiten ---------------------------------------------------
  fprintf('******************************************');
  fprintf('******************************************');
  fprintf('\n\nTestfall %d: %s\n', testFall, beschr);
  
  % Polynom mit eigener Funktion hornerSchema auswerten
  pHorner  = hornerSchema(a, t);
  
  % Polynom mit Matlab-Funktion polyval auswerten
  pPolyval = polyval(a(end:-1:1), t);
  
  % Ergebnisse fuer alle t ausgeben ---------------------------------------
  for i = 1:length(t)
    fprintf('\n');
    fprintf('t = %g:\n', t(i));
    fprintf('\t%-43s %26.15f\n', ...
      'Auswertung mit dem Horner-Schema:', pHorner(i));
    fprintf('\t%-43s %26.15f\n', ...
      'Auswertung mit der Matlab-Funktion polyval:', pPolyval(i));
    fprintf('\t%-43s %26.15f\n', lsgStr, pExakt(i));
  end
end
