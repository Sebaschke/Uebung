function values = nevilleAitken2( xk, fk, t )
% Angewandte Numerik 1, SoSe 2020
% Uebungsblatt 11, Aufgabe 48: Schema von Neville-Aitken
%
% Die Funktion values = nevilleAitken2(xk, fk, t) berechnet die
% Funktionswerte des Interpolationspolynoms P(f|x0,...,xn) von f zu
% den Stuetzstellen xk (x0,...,xn) an mehreren Stellen t mit Hilfe des
% Schemas von Neville-Aitken, berechnet also P(f | xk(1), ..., xk(end))(t)
%
% Variante nevilleAitken2 mit 1 For-Schleife: Vektorisierte Schleifen:
%   -	Innerste For-Schleife: Berechnet alle Werte einer Spalte.
%   - Aeusserste For-Schleife: Wertet Polynom fuer alle Werte aus t aus.
%
% Input:    xk        Vektor der Stuetzstellen x0,...,xn des
%                     Interpolationspolynoms
%           fk        Vektor der Funktionswerte f0,...,fn der zu
%                     interpolierenden Funktion an den Stuetzstellen
%           t         Vektor der Stellen t0,...,tm, an denen das
%                     Interpolationspolynoms ausgewertet werden soll
% Output:   values    Vektor der Funktionswerte v1,...,vm des
%                     Interpolationspolynoms an den Stellen t, also
%                     vk = P(f|x0,...,xn)(tk) fuer k = 1,...,m.
%
% Letzte Aenderung: 06.07.2020

  % Sicherstellen, dass xk und fk Spaltenvektoren sind
  xk = xk(:);
  fk = fk(:);
  
  % Sicherstellen, dass t ein Zeilenvektor ist
  t = t(:)';

  % Anzahl der Stuetzstellen
  n = length(fk);
  
  % Anzahl der Stuetzstellen = Anzahl der Funktionswerte
  if( n ~= length(xk) )
    fprintf( 2, ...
      '\nAnzahl der Stuetzstellen und Funktionswerte nicht gleich !\n\n' );
    values = [];
    return;
  end

  % Anzahl der Stellen, an denen ausgewertet werden soll
  m = length(t);

  % Zeilenvektor: fuer jede Auswertestelle eine 1
  einsT   = ones(1,m);
  
  % Matrix, enthaelt fuer jedes ti eine Spalte mit den Funktionswerten
  matrixP = fk * einsT;

  % Neville-Aitken Schema spaltenweise parallel fuer jedes t durchfuehren
  for k = 2:n
    matrixP(k:n,:) = matrixP(k:n,:)              ...
      + (ones(n-k+1,1)*t - xk(k:n)*einsT)        ...
      ./ ((xk(k:n)*einsT - xk(1:n-k+1)*einsT))   ...
      .* (matrixP(k:n,:) - matrixP(k-1:n-1,:));
  end

  % Funktionswert an den Auswertestelle speichern
  values = matrixP(n,:);
end
