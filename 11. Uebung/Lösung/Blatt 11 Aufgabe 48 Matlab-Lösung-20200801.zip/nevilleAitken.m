function values = nevilleAitken( xk, fk, t )
% Angewandte Numerik 1, SoSe 2020
% Uebungsblatt 11, Aufgabe 48: Schema von Neville-Aitken
%
% Die Funktion values = nevilleAitken(xk, fk, t) berechnet die
% Funktionswerte des Interpolationspolynoms P(f|x0,...,xn) von f zu
% den Stuetzstellen xk (x0,...,xn) an mehreren Stellen t mit Hilfe des
% Schemas von Neville-Aitken, berechnet also P(f | xk(1), ..., xk(end))(t)
%
% Variante nevilleAitken mit 3 For-Schleifen, nicht vektorisiert.
%
% Input:    xk        Vektor der Stuetzstellen x0,...,xn des
%                     Interpolationspolynoms
%           fk        Vektor der Funktionswerte f0,...,fn der zu
%                     interpolierenden Funktion an den Stuetzstellen
%           t         Vektor der Stellen t0,...,tm, an denen das
%                     Interpolationspolynoms ausgewertet werden soll
% Output:   values    Vektor der Funktionswerte v1,...,vm des
%                     Interpolationspolynoms an den Stellen t, also
%                     vk = P(f|x0,...,xn)(tk) fuer k = 1,...,m.
%
% Letzte Aenderung: 06.07.2020

  % Anzahl der Stuetzstellen
  n = length(fk);
  
  % Anzahl der Stuetzstellen = Anzahl der Funktionswerte
  if( n ~= length(xk) )
    fprintf( 2, ...
      '\nAnzahl der Stuetzstellen und Funktionswerte nicht gleich !\n\n' );
    values = [];
    return;
  end

  % Anzahl der Stellen, an denen ausgewertet werden soll
  m = length(t);

  % Vektor der Funktionswerte des Interpolationspolynom initialisieren
  values = zeros(size(t));

  % Loop ueber alle Auswertestellen t
  for j = 1:m
    % Einzelne Auswertestelle
    tj = t(j);
    
    % Fuer jede Auswertestelle komplett neues Schema
    P = fk;
    
    % Schema von Neville-Aitken spaltenweise durchfuehren
    for k = 2:n
      for l = n:-1:k
        P(l) = P(l) + (tj-xk(l)) / (xk(l)-xk(l-k+1)) * (P(l) - P(l-1));
      end
    end
    
    % Funktionswert an einzelner Auswertestelle speichern
    values(j) = P(end);
  end
end