% Angewandte Numerik 1, SoSe 2020
% Uebungsblatt 11, Aufgabe 48: Schema von Neville-Aitken
%
% Berechnet einen Naeherungswert von sqrt(3) mit Hilfe des Schemas
% von Neville-Aitken mit 4 und 5 Stuetzstellen und 3 Programm-Varianten:
%  - nevilleAitken mit 3 For-Schleifen, nicht vektorisiert
%  - nevilleAitken1 mit 2 For-Schleifen: Innerste For-Schleife vektorisiert
%  - nevilleAitken2 mit 1 For-Schleife: Innerste und aeusserste 
%    For-Schleife vektorisiert
%
% Letzte Aenderung: 06.07.2020

% Cleanup
clearvars;
close all;
clc;

% Initialisierung ---------------------------------------------------------
fprintf( '\nAngewandte Numerik 1, Sommersemester 2020\n' );
fprintf( 'Uebungsblatt 11, Aufgabe 48: Schema von Neville-Aitken\n\n' );
fprintf( ['|     Berechnung von sqrt(3) durch Interpolation der ', ...
  'Funktion f(x) = 3^x          |\n'] );
fprintf( '|---------------------------------------------------' );
fprintf( '------------------------------|\n' );

% Die zu interpolierende Funktion
f        = @(x) 3.^x;

% 4 Stuetzstellen, x = (x0,x1,...,xn)' und zugehoerige Funktionswerte
x4       = [-2; -1; 0; 1];
fx4      = f(x4);

% 5 Stuetzstellen, x = (x0,x1,...,xn)' und zugehoerige Funktionswerte
x5       = [-2; -1; 0; 1; 2];
fx5      = f(x5);

% Auswerte-Stelle
t        = 1/2;

% Ergebnismatrix und Fehlermatrix initialisieren
% 1. Spalte: Anzahl der Schleifen des Verfahrens
% 2. Spalte: Naehrerungswert fuer 4 Stuetzstellen
% 3. Spalte: Fehler fuer 4 Stuetzstellen
% 4. Spalte: Naehrerungswert fuer 5 Stuetzstellen
% 5. Spalte: Fehler fuer 5 Stuetzstellen
erg      = zeros( 3, 5 );
erg(:,1) = (3:-1:1)';

% Neville-Aitken Schema fuer 4 Stuetzstellen ------------------------------
erg(1,2) = nevilleAitken ( x4, fx4, t );
erg(2,2) = nevilleAitken1( x4, fx4, t );
erg(3,2) = nevilleAitken2( x4, fx4, t );

% Neville-Aitken Schema fuer 5 Stuetzstellen ------------------------------
erg(1,4) = nevilleAitken ( x5, fx5, t );
erg(2,4) = nevilleAitken1( x5, fx5, t );
erg(3,4) = nevilleAitken2( x5, fx5, t );

% Fehlerberechnung und Ausgabe --------------------------------------------
% Fehlerberechnung: Spalte 3 fuer 4, Spalte 5 fuer 5 Stuetzstellen
erg(:,[3,5]) = sqrt(3) - erg(:,[2,4]);

% Da Matlab Matrizen spaltenweise liest, muss die Ergebnismatrix
% fuer eine zeilenweise Ausgabe transponiert werden
fprintf( '| Neville-Aitken   |      Mit 4 Stuetzstellen      |' );
fprintf( '      Mit 5 Stuetzstellen     |\n' );
fprintf( '| Programmvariante |  Naeherung   |     Fehler     |' );
fprintf( '  Naeherung   |    Fehler     |\n' );
fprintf( '|------------------|--------------|----------------|' );
fprintf( '--------------|---------------|\n' );
fprintf( ['| Mit %d For-Loops  | %12.10f | %13.07e | %12.10f | ', ...
  '%13.07e |\n'], erg' ); 