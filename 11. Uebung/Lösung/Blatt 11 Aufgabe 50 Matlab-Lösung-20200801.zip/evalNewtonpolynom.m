% Angewandte Numerik 1, SoSe 2020
% Uebungsblatt 12, Aufgabe 48: Schema der Dividierten Differenzen
%
% Die Funktion fx = evalNewtonpolynom(x, c, t)
% wertet das Polynom zur Newton-Basis an allen Stellen t aus
%
% Parameter:
%   x:      die Stuetzstellen der Newton-Basis, x = (x0,x1,...,xn)'
%   c:      die Koeffizienten des Polynoms, c = (c0,c1,c2,...,cn)'
%   t:      die Punkte, an denen ausgewertet werden soll
%
% Rueckgabewert:
%   fx:     Wert des durch c gegebenen Polynoms,
%           ausgewertet an allen Stellen t



function  fx = evalNewtonpolynom(x, c, t)


%% Initialisierungen

n = length(c);                  % Grad des Polynoms p
n = n-1;                        % da Vektoren mit Index 0 beginnen



%% Horner-aehnliches Schema

fx  = c(n+1) * ones(size(t));	% der hoechste Koeffizient
for i = n:-1:1                  % die restlichen Koeffizienten ablaufen
    fx  = fx.*(t-x(i)) + c(i);
end


end