function c = divDiffv(x, f)
% Angewandte Numerik 1, SoSe 2020
% Uebungsblatt 11, Aufgabe 50: Schema der Dividierten Differenzen
%
% Die Funktion c = divDiffv(x, f) berechnet mittels dividierter
% Differenzen den Vektor c = (c_0, ..., c_n)' der Koeffizienten 
% des Newton-Interpolationspolynoms zu den Stuetzstellen
% x = (x_0, ..., x_n)' und den Funktionswerten f = (f_0, ..., f_n)'
% an diesen Stuetzstellen.
%
% Variante divDiffv: Vektorisierte Formulierung
%
% Input:  x     Spaltenvektor der Stuetzstellen, x = (x0, ..., xn)'
%         f     Spaltenvektor der Funktionswerte f = (f(x0), ..., f(xn))
%               der zu interpolierenden Funktion an den Stuetzstellen
% Output: c     Spaltenvektor der Koeffizienten des Newton'schen
%               Interpolationspolynoms
%
% Letzte Aenderung: 06.07.2020

  % Initialisierung -------------------------------------------------------
  % Anzahl der Stuetzstellen
  n = length(x);
  
  % Leerer Ausgabevektor im Fehlerfall
  c = [];
  % Plausibilitaetspruefungen
  if (length(f) ~= n)
    fprintf( 2, ['divDiff: Vektoren der Stuetzpunkte und der ', ...
      'Funktionswerte nicht gleich lang!'] );
    return;
  end
  
  if (n == 0)
    fprintf( 2, 'divDiff: Die Eingabeparameter haben Vektorlaenge 0' );
    return;
  end
  
  % Sicherstellen, dass x und Spaltenvektoren sind
  x = x(:);
  f = f(:);
  
  % Schema der dividierten Differenzen ------------------------------------
  % Spaltenweise im Schema der Dividierten Differenzen vorgehen
  for k = 2:n
    f(k:n) = (f(k-1:n-1) - f(k:n)) ./ (x(1:n-k+1) - x(k:n));
  end
  
  % Rueckgabewert: Die berechneten Koeffizienten stehen im Schema
  % der Dividierten Differenzen auf der Diagonalen
  c = f;
end