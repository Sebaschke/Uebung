% Angewandte Numerik 1, SoSe 2020
% Uebungsblatt 11, Aufgabe 50: Schema der Dividierten Differenzen
%
% Berechnet einen Naeherungswert von sqrt(3) mit Hilfe des Schemas
% der Dividierten Differenzen mit 4 und 5 Stuetzstellen und 
% 2 Programm-Varianten:
%  - divDiff  mit 2 For-Schleifen, nicht vektorisiert
%  - divDiffv mit 1 For-Schleife, vektorisiert
%
% Letzte Aenderung: 11.07.2020

% Cleanup
clearvars;
close all;
clc;

% Initialisierung ---------------------------------------------------------
fprintf( '\nAngewandte Numerik 1, Sommersemester 2020\n' );
fprintf( ['Uebungsblatt 11, Aufgabe 50: Schema der Dividierten ' ...
  'Differenzen\n\n'] );
fprintf( ['|     Berechnung von sqrt(3) durch Interpolation der ', ...
  'Funktion f(x) = 3^x          |\n'] );
fprintf( '|---------------------------------------------------' );
fprintf( '------------------------------|\n' );

% Die zu interpolierende Funktion
f        = @(x) 3.^x;

% 4 Stuetzstellen, x = (x0,x1,...,xn)' und zugehoerige Funktionswerte
x4       = [-2; -1; 0; 1];
fx4      = f(x4);

% 5 Stuetzstellen, x = (x0,x1,...,xn)' und zugehoerige Funktionswerte
x5       = [-2; -1; 0; 1; 2];
fx5      = f(x5);

% Auswerte-Stelle
t        = 1/2;

% Ergebnismatrix und Fehlermatrix initialisieren
% 1. Spalte: Anzahl der Schleifen des Verfahrens
% 2. Spalte: Naehrerungswert fuer 4 Stuetzstellen
% 3. Spalte: Fehler fuer 4 Stuetzstellen
% 4. Spalte: Naehrerungswert fuer 5 Stuetzstellen
% 5. Spalte: Fehler fuer 5 Stuetzstellen
erg      = zeros( 2, 5 );
erg(:,1) = (2:-1:1)';

% Schema der Dividierten Differenzen fuer 4 Stuetzstellen -----------------
% Berechnung der Koeffizienten des Newton-Interpolationspolynoms
% mittels dividierter Differenzen
c4  = divDiff(x4, fx4);
c4v = divDiffv(x4, fx4);

% Auswertung des Polynoms zur Newton-Basis mit modifiziertem Horner-Schema
erg(1,2) = evalNewtonpolynom(x4, c4,  t);
erg(2,2) = evalNewtonpolynom(x4, c4v, t);

% Schema der Dividierten Differenzen fuer 5 Stuetzstellen -----------------
% Berechnung der Koeffizienten des Newton-Interpolationspolynoms
% mittels dividierter Differenzen
c5  = divDiff(x5, fx5);
c5v = divDiffv(x5, fx5);

% Auswertung des Polynoms zur Newton-Basis mit modifiziertem Horner-Schema
erg(1,4) = evalNewtonpolynom(x5, c5,  t);
erg(2,4) = evalNewtonpolynom(x5, c5v, t);

% Fehlerberechnung und Ausgabe --------------------------------------------
% Fehlerberechnung: Spalte 3 fuer 4, Spalte 5 fuer 5 Stuetzstellen
erg(:,[3,5]) = sqrt(3) - erg(:,[2,4]);

% Da Matlab Matrizen spaltenweise liest, muss die Ergebnismatrix
% fuer eine zeilenweise Ausgabe transponiert werden
fprintf( '| Dividierte       |      Mit 4 Stuetzstellen      |' );
fprintf( '      Mit 5 Stuetzstellen     |\n' );
fprintf( '| Differenzen      |  Naeherung   |    Fehler      |' );
fprintf( '  Naeherung   |    Fehler     |\n' );
fprintf( '|------------------|--------------|----------------|' );
fprintf( '--------------|---------------|\n' );
fprintf( ['| Mit %d For-Loops  | %12.10f | %13.07e | %12.10f | ', ...
  '%13.07e |\n'], erg' ); 