% Angewandte Numerik 1, Blatt 3, Aufgabe 8
%
% Fuehrt fuer regulaere Matrizen eine Zeilen- oder Spaltenaequilibrierung
% mit 1-Norm oder Inf-Norm durch.
%
% Letzte Aenderung: 13.05.2020

% Initialisierung
clearvars;
fprintf( "\nAngewandte Numerik 1, Blatt 3, Aufgabe 8\n" );

% Es werden 2 verschiedene Matrizen erzeugt
% Anzahl der Zeilen der Matrizen
rows   = [ 5, 7 ];
% Anzahl der Spalten der Matrizen
cols   = [ 6, 5 ];
% Verschiebung des Wertebereichs der rand Funktion
% mit shft = -0.5 Verschiebung des Wertebereichs von [0,1] nach [-0.5,0.5]
shft   = [ 0, -0.5 ];
% Skalierung des Wertebereichs der rand Funktion
scal   = [ 50, 200 ];

% Kombinationen von Norm und type
Norms = [ "one",  "one",  "infty", "infty" ];
Types = [ "rows", "cols", "rows",  "cols"  ];

% Aequilibrierung der Matrizen
for k = 1:length(rows)
  % Erzeugung der Matrix
  A = ( rand( rows(k), cols(k) ) + shft(k) ) * scal(k);
  
  % Ausgabe der Matrix
  fprintf( "\n--------------------------------------------------------\n");
  fprintf( "Matrix A:\n" );
  disp( A )
  
  for comb = 1:length(Norms)
    % Norm und type fuer die Aequilibrierung festlegen
    Norm = Norms(comb);
    type = Types(comb);
    fprintf("\nAequilibrierung von A mit Norm='%s', type='%s':\n", ...
      Norm, type);
    
    % Diagonalmatrizen D, die die Matrix A aequlilibriert
    D = normalizeMat(A, Norm, type);
    
    % Weitere Ausgabe nur dann, wenn in normalizeMat keine Fehler waren
    if( ~all( isnan(D), 'all' ) )
      % Ausgabe der Diagonalmatrix
      fprintf(" - Diagonalmatrix D, die die Matrix A aequlilibriert:\n");
      disp( D )
      
      % Ausgabe der aequilibrierten Matrix
      if( type == "rows" )
        % Ausgabe der aequilibrierten Matrix bei type = rows
        fprintf ...
          (" - Matrix A aequilibriert mit Matrix D: E = D*A :");
        E = D * A;
        
        % Berechnung der zeilenweisen Norm
        fprintf("    Zeilenweise %s Norm\n", Norm);
        if( Norm == "one" )
          for k1 = 1:size(E,1)
            fprintf( "  %8.4f", E(k1,:) );
            fprintf( " :    1-Norm: %8.4f\n", norm( E(k1,:), 1 ) );
          end
        else
          for k2 = 1:size(E,1)
            fprintf( "  %8.4f", E(k2,:) );
            fprintf( " :  Inf-Norm: %8.4f\n", norm( E(k2,:), 'inf' ) );
          end
        end
        
      else
        % Ausgabe der aequilibrierten Matrix bei type = cols
        fprintf ...
          (" - Matrix A aequilibriert mit Diagonalmatrix D: E = A*D :\n");
        E = A * D;
        for k3 = 1:size(E,1)
          fprintf( "  %8.4f", E(k3,:) );
          fprintf( "\n" );
        end
        
        % Berechnung der spaltenweisen Norm
        fprintf("   Spaltenweise %s Norm:\n", Norm);
        if( Norm == "one" )
          for k4 = 1:size(E,2)
            fprintf( "  %8.4f", norm( E(:,k4), 1 ) );
          end
          fprintf( "\n" );
        else
          for k4 = 1:size(E,2)
            fprintf( "  %8.4f", norm( E(:,k4), 'inf' ) );
          end
          fprintf( "\n" );
        end
      end
    end
  end
end