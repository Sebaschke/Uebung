function D = normalizeMat(A, Norm, type)
% Angewandte Numerik 1, Blatt 3, Aufgabe 8
%
% Fuer eine regulaere Matrix A in R^(n x n) wird eine Aequilibrierung
% durchgefuehrt 
%
% Input:  A       Die zu aequilibrierende regulaere Matrix
%         Norm    Ein String, der festlegt, ob bezueglich der Maximumnorm
%                 (norm == 'infty') oder bezueglich der Summennorm 
%                 (norm == 'one') aequilibriert werden soll
%         type    Ein String, der die Art der Aequilibrierung festlegt.
%                 Es soll gelten:
%                   ||(DA)_i||=1, fuer alle i in {1,...,n}, 
%                        falls type == 'rows' ist, wobei (DA)_i die
%                        i-te Zeile der Matrix DA ist
%                   ||(DA)_j||=1, fuer alle j in {1,...,n},
%                        falls type == 'cols' ist, wobei (DA)_j die
%                        die j-te Spalte der Matrix AD bezeichnen
% Output: D       Die Diagonalmatrix, die die Matrix A aequlilibriert.

  % Initialisierung und Fehlerbehandlung
  % Die Ausgabevariable muss auch im Fehlerfall gesetzt sein
  D = NaN;
  
  % Sicherstellen, dass Norm ein Character-Vektor oder ein String ist
  if( ~ischar(Norm) && ~isstring(Norm) )
    % Fehler: Norm ist kein String
    fprintf( "\nEingabevariable Norm = %s ist kein String !!\n\n", ...
      string( flag ) );
    return;
  end
  
  % Sicherstellen, dass type ein Character-Vektor oder ein String ist
  if( ~ischar(type) && ~isstring(type) )
    % Fehler: type ist kein String
    fprintf( "\nEingabevariable Norm = %s ist kein String !!\n\n", ...
      string( flag ) );
    return;
  end
  
  % Sicherstellen, dass Norm, type Zeilenvektoren sind, umwandeln in String
  Norm = string( Norm(:)' );
  type = string( type(:)' );
  
  if( type == "cols" )
    % Transponieren der Matrix bei Spalten-Aequilibrierung
    A = A';
  elseif( type ~= "rows" )
    fprintf( "\nFalscher Type %s eingegeben\n\n", type );
    return;
  end
    
  % Aequilibrierung
  switch Norm
    case "one"
      W = sum( abs( A ), 2 );
      % Alternativ: W = abs(A)*ones(length(A),1);
    case "infty"
      W = max( abs( A ), [], 2 );
      % Alternativ: W = max(abs(A'));
    otherwise
      fprintf( "\nFalsche Norm %s eingegeben\n\n", Norm );
      return;
  end
  
  % Matrix regulaer?
  if( prod( W ) == 0 )
    fprintf('\nMatrix A ist nicht regulaer\n\n');
    return;
  end
  
  % Diagonalmatrix, die die Matrix A aequlilibriert
  D = diag( 1 ./ W );
end