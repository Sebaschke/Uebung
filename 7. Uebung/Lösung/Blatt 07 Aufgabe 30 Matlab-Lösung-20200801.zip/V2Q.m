function Q = V2Q( V )
% Angewandte Numerik 1, SoSe 2020
% Uebungsblatt 07, Aufgabe 29: QR-Zerlegung mit Householder-Spiegelungen
% 
% Berechnet aus der linken unteren Dreiecksmatrix
% V = (v_1, v_2, ..., v_n) einer QR-Zerlegung, die in ihren Spalten
% die Householder-Vektoren v_i der einzelnen Spiegelungen enthaelt,
% die orthogonale Matrix Q der QR-Zerlegung.
%
% Input:  V     Linke untere Dreiecksmatrix V = (v_1, v_2, ..., v_n)
%               einer QR-Zerlegung, die in ihren Spalten die
%               Householder-Vektoren v_i der einzelnen Spiegelungen
%               enthaelt
% Output: Q     Orthogonale Matrix Q der QR-Zerlegung
%
% Letzte Aenderung: 09.06.2020

  % Dimension der Matrix
  [m,n] = size(V);

  % Erzeuge orthogonale Matrix Q
  Q = eye(m);
  for j = 1:n
    v = [ zeros( j-1, 1 ); 1; V(j+1:m,j) / V(j,j) ];
    Q = Q - 2 / ( v' * v ) * v * ( v' * Q );
  end
  Q = Q';
end