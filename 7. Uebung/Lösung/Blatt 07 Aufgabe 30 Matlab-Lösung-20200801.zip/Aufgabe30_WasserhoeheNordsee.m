% Angewandte Numerik 1, SoSe 2020
% Uebungsblatt 07, Aufgabe 30: Lineares Ausgleichsproblem
%
% Lineares Ausgleichsproblem min(||Ax - b||^2) zur Approximation der
% Wasserhoehe in der Nordsee
%
% Letzte Aenderung: 09.06.2020

% Cleanup -----------------------------------------------------------------
clearvars
close all
clc

% Initialisierung ---------------------------------------------------------
% Messdaten
T = [0; 2; 4; 6; 8; 10];
H = [19/10; 3; 13/5; 11/10; 2/5; 3/2];

% Zeitpunkte f�r Ausgleichskurve
t = -2:0.05:12;

% L�sung des Ausgleichsproblems -------------------------------------------
% Formulierung als Ausgleichsproblem
A = [ ones(6,1), sin( (2 * pi / 12) * T), cos( (2 * pi / 12) * T) ];
b = H ;                                             

% Loese A*x = b
[V, R] = qrHouseholder(A);
x      = solveHouseholder(V, R, H);

% Funktion der Ausgleichskurve
h = @(t) x(1) + x(2)*sin((2*pi/12)*t) + x(3)*cos((2*pi/12)*t);

% Plotten der Messpunkte, der Ausgleichskurve und der Fehler --------------
hf1 = figure( 'Name', 'Angewandte Numerik 1, Blatt 7, Aufgabe 30',  ...
  'NumberTitle', 'off', 'Units', 'normalized', 'MenuBar', 'None',   ...
  'Position', [0.15, 0.1, 0.70, 0.85] );

% Ausgleichskurve plotten
plot( t, h(t), 'g-', 'LineWidth', 2, 'Display', 'Ausgleichskurve' );
hold on;

% Messpunkte plotten
plot( T, H, 'bo', 'LineWidth', 2, 'Display', 'Messpunkte', ...
  'MarkerSize', 6 );

% Fehler plotten
for k = 1:length(T)
  plot( [ T(k), T(k) ], [ H(k), h(T(k)) ], 'r-', 'LineWidth', 3, ...
    'Display', 'Fehler der L�sung' );
  legend( 'autoupdate', 'off' );
end

% Achsen, Label, Legende und Titel
set( gca, 'FontSize',12)
axis( [-2.0, 12.0, 0.0, 3.5] );
xlabel( 'Zeit t [h]', 'FontSize', 14 );
ylabel( 'Hoehe des Wasserstandes h [m]', 'FontSize', 14 );
hl = legend( 'Show', 'Location', 'NorthEast' );
hl.FontSize = 14;
title( 'Wasserstand der Nordsee: Lineares Ausgleichsproblem', ...
  'FontSize', 20);